function adjustIframeHeight() {
    const iframeHeight = document.body.scrollHeight;
    window.parent.postMessage({ height: iframeHeight }, '*'); // Replace '*' with your parent domain in production
}

// Call adjustIframeHeight() after the content loads.  We can do this in a couple of ways:
// A) Using window.onload:
window.onload = adjustIframeHeight;

// B) Or, if you want to be absolutely sure everything is loaded, including images:
// window.addEventListener('load', adjustIframeHeight); // For images and other resources

// Listen for theme toggle messages from the parent document
window.addEventListener('message', (event) => {
    if (event.data.theme) {
        document.body.classList.toggle('light-theme', event.data.theme === 'light');
    }
});
