# Instructions on Converting DB2 Stored Procedures to PostgreSQL Functions

## 1. Introduction

### Objective

This document provides a comprehensive, systematic framework used for the migration of IBM DB2 stored procedures to PostgreSQL functions. The objective of this migration is to ensure the semantic and syntactic fidelity of database logic while enhancing maintainability, scalability, and interoperability within the AMEX enterprise architecture. The focus is on the LETT (Live Event Tracking Tool) and EMS (Experiential Marketing Services) modules under GABM (Global Advertising and Brand Management). These modules play a critical role in AMEX’s data-driven decision-making process, and the migration must ensure uninterrupted functionality and optimized performance.

This methodology accounts for architectural differences between DB2 and PostgreSQL, including:

- Variations in procedural languages (SQL PL vs. PL/pgSQL)
- Data type equivalencies and constraints
- Transaction management and exception handling paradigms

### Scope

This document covers the following aspects of the DB2 to PostgreSQL migration:

- Identification and categorization of stored procedures for conversion
- Step-by-step procedural transformations, including syntax conversion and logic restructuring
- Schema consistency requirements and database object mapping
- Implementation of robust error handling mechanisms
- Ensuring seamless integration with existing business logic and applications

### Organization

- **Enterprise:** AMEX
- **Relevant Modules:**
  - LETT - Live Event Tracking Tool
  - EMS - Experiential Marketing Services

---

## 2. Prerequisites

### Software Requirements

A complete migration requires the following software and tools:

- **DBeaver** – A robust database management tool that provides a comprehensive interface for querying, managing, and interacting with both DB2 and PostgreSQL databases. It supports advanced features such as data visualization, SQL debugging, and database schema comparison, making it an essential tool for database administrators and developers during the migration process.
- **Docker** – Enables containerized PostgreSQL instance deployment for testing.
- **VS Code** – Serves as the primary Integrated Development Environment (IDE) for writing and debugging SQL scripts. It offers extensive support for SQL development through various extensions, such as the SQL Server (mssql) extension for connecting to DB2 and PostgreSQL databases. VS Code provides features like IntelliSense for SQL, code snippets, and integrated terminal, which streamline the development and debugging process. Additionally, its version control integration with GitHub ensures efficient collaboration and code management during the migration.
- **Excel** – Used for data comparisons and validation analysis.
- **PostgreSQL (local instance)** – Ensures local testing before deployment.
- **GitHub Copilot** – Provides AI-driven code suggestions to expedite SQL translation. While AMEX allows only autocomplete features, GitHub Copilot can still significantly enhance productivity by offering context-aware code completions, reducing manual coding effort, and minimizing syntax errors. This tool integrates seamlessly with VS Code, ensuring that developers can leverage its capabilities within their preferred development environment.

### Access Requirements

To perform the migration successfully, the following access permissions are mandatory:

- **DB2 Database Credentials** – Required to extract stored procedures and analyze existing logic.
- **E1 Server (PostgreSQL Development Environment)** – Used for iterative testing and validation.
- **E2 Server (Pre-Production Testing Instance)** – Facilitates integration testing before production deployment.
- **JIRA** – Tracks migration progress, tickets, and dependencies.
- **GitHub Copilot** – Provides AI-driven suggestions for SQL translation and error correction.
- **Network Proxy Access** – Ensures connectivity between development tools and database environments.

---

## 3. Conversion Methodology

### Procedural Transformation

#### 1. Translating DB2 Stored Procedures to PostgreSQL Functions

- Maintain semantic equivalence across all parameters and logic flows.
- Adhere strictly to schema conventions, ensuring functions are created under `tgabm10`.

##### Example: DB2 Stored Procedure

```sql
CREATE PROCEDURE SYSPROC.SP_SAMPLE (IN P_ID INT, OUT P_NAME VARCHAR(50))
BEGIN
    SELECT NAME INTO P_NAME FROM TGABM10.USERS WHERE ID = P_ID;
END;
```

##### Equivalent PostgreSQL Function

```sql
CREATE OR REPLACE FUNCTION tgabm10.sp_sample(p_id INT, OUT p_name VARCHAR(50)) RETURNS RECORD AS $$
BEGIN
    SELECT name INTO p_name FROM tgabm10.users WHERE id = p_id;
END;
$$ LANGUAGE plpgsql;
```

#### 2. Retaining Logical Structure During Migration

The logical structure of a stored procedure must be preserved to maintain business logic consistency. To achieve this:

- Preserve conditional structures (`IF`, `CASE`, `LOOP`).
- Retain explicit transaction control (if applicable).
- Ensure that control-flow statements such as `LEAVE`, `ITERATE`, `GOTO` and `RETURN` are correctly mapped.

##### Example: Comprehensive DB2 Logic Retention

###### DB2 Stored Procedure

```sql
CREATE PROCEDURE SYSPROC.SP_COMPLEX_LOGIC (IN P_ID INT, OUT P_RESULT VARCHAR(50))
BEGIN
    DECLARE V_COUNT INT;
    DECLARE V_NAME VARCHAR(50);
    DECLARE V_STATUS CHAR(1);
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        SET P_RESULT = 'Error Occurred';
    END;

    -- Conditional structure using IF
    SELECT COUNT(*) INTO V_COUNT FROM TGABM10.USERS WHERE ID = P_ID;
    IF V_COUNT = 0 THEN
        SET P_RESULT = 'User Not Found';
        RETURN;
    END IF;

    -- Conditional structure using CASE
    SELECT NAME, STATUS INTO V_NAME, V_STATUS FROM TGABM10.USERS WHERE ID = P_ID;
    CASE V_STATUS
        WHEN 'A' THEN SET P_RESULT = V_NAME || ' is Active';
        WHEN 'I' THEN SET P_RESULT = V_NAME || ' is Inactive';
        ELSE SET P_RESULT = V_NAME || ' has Unknown Status';
    END CASE;

    -- Loop structure with LEAVE and ITERATE
    DECLARE C1 CURSOR FOR SELECT NAME FROM TGABM10.USERS;
    OPEN C1;
    FETCH C1 INTO V_NAME;
    WHILE V_NAME IS NOT NULL DO
        IF V_NAME = 'John Doe' THEN
            ITERATE;
        END IF;
        IF V_NAME = 'Jane Doe' THEN
            LEAVE;
        END IF;
        FETCH C1 INTO V_NAME;
    END WHILE;
    CLOSE C1;

    -- GOTO statement
    IF V_COUNT > 10 THEN
        GOTO END_PROCEDURE;
    END IF;

    SET P_RESULT = 'Completed Successfully';

    END_PROCEDURE:
    RETURN;
END;
```

###### PostgreSQL Equivalent

```sql
CREATE OR REPLACE FUNCTION tgabm10.sp_complex_logic(p_id INT, OUT p_result VARCHAR(50)) RETURNS RECORD AS $$
DECLARE
    v_count INT;
    v_name VARCHAR(50);
    v_status CHAR(1);
    c1 CURSOR FOR SELECT name FROM tgabm10.users;
BEGIN
    -- Conditional structure using IF
    SELECT COUNT(*) INTO v_count FROM tgabm10.users WHERE id = p_id;
    IF v_count = 0 THEN
        p_result := 'User Not Found';
        RETURN;
    END IF;

    -- Conditional structure using CASE
    SELECT name, status INTO v_name, v_status FROM tgabm10.users WHERE id = p_id;
    CASE v_status
        WHEN 'A' THEN p_result := v_name || ' is Active';
        WHEN 'I' THEN p_result := v_name || ' is Inactive';
        ELSE p_result := v_name || ' has Unknown Status';
    END CASE;

    -- Loop structure with LEAVE and ITERATE
    OPEN c1;
    FETCH c1 INTO v_name;
    WHILE v_name IS NOT NULL LOOP
        IF v_name = 'John Doe' THEN
            CONTINUE;
        END IF;
        IF v_name = 'Jane Doe' THEN
            EXIT;
        END IF;
        FETCH c1 INTO v_name;
    END LOOP;
    CLOSE c1;

    -- GOTO statement equivalent
    IF v_count > 10 THEN
        p_result := 'Didnt Complete Successfully';
    END IF;

    if p_result != 'Didnt Complete Successfully' THEN
        p_result := 'Completed Successfully';
    END IF;

    RETURN;
END;
$$ LANGUAGE plpgsql;
```
This transformation ensures that the procedural logic remains intact while adhering to PostgreSQL’s syntax. The above examples illustrate how DB2 stored procedures can be converted to PostgreSQL functions, maintaining the original logic and structure.

#### 3. Output Handling and Cursor Implementation

- Convert DB2 `OUT` parameters into PostgreSQL function return records. This is achieved by explicitly defining a composite type or utilizing an implicit record structure in the function signature.

##### Example: DB2 Stored Procedure with OUT Parameters

```sql
CREATE PROCEDURE SYSPROC.SP_SAMPLE (IN P_ID INT, OUT P_NAME VARCHAR(50))
BEGIN
    SELECT NAME INTO P_NAME FROM SYSPROC.USERS WHERE ID = P_ID;
END;
```

##### Equivalent PostgreSQL Function

```sql
CREATE OR REPLACE FUNCTION tgabm10.sp_sample(p_id INT, OUT p_name VARCHAR(50)) RETURNS RECORD AS $$
BEGIN
    SELECT name INTO p_name FROM tgabm10.users WHERE id = p_id;
END;
$$ LANGUAGE plpgsql;
```

In this conversion, the PostgreSQL function explicitly defines the `OUT` parameter as part of the function signature, automatically returning the values as a record. This ensures compatibility while preserving the procedural intent of the original DB2 stored procedure.

- Explicitly define cursor-based result sets with an `OUT` parameter (`RESULT_SET_1`).
##### Example: DB2 Stored Procedure with Cursor Logic

```sql
CREATE PROCEDURE SYSPROC.SP_CURSOR_SAMPLE (IN P_ID INT)
BEGIN
    DECLARE C1 CURSOR WITH RETURN FOR
    SELECT NAME FROM SYSPROC.USERS WHERE ID = P_ID;
    
    OPEN C1;
END;
```

##### Equivalent PostgreSQL Function

```sql
CREATE OR REPLACE FUNCTION tgabm10.sp_cursor_sample(p_id INT, OUT result_set_1 refcursor) RETURNS RECORD AS $$
 BEGIN   
    OPEN result_set_1 FOR
        SELECT name FROM tgabm10.users WHERE id = p_id;
 END;
$$ LANGUAGE plpgsql;
```

In this conversion, the PostgreSQL function uses a `refcursor` to handle the cursor logic. The cursor is opened for the specified query and returned as part of the function's output, ensuring compatibility with the original DB2 stored procedure.
- Standardize error propagation using `SQLCODE CHAR(10)` and `ERR_MSG CHAR(100)` for enhanced debugging.

#### 4. Exception Handling in PostgreSQL

- Utilize `BEGIN...EXCEPTION...END` for structured error management.

##### Example:

```sql
BEGIN
    -- SQL operation
EXCEPTION
    WHEN OTHERS THEN
        ERR_MSG := SQLERRM;
END;
```

- Prevent `NO_DATA_FOUND` errors by performing explicit null-value checks before `INTO` operations. This can be accomplished by verifying the presence of data prior to attempting a selection. For example:

```sql
DECLARE v_exists INT;
BEGIN
    SELECT 1 INTO v_exists FROM tgabm10.users WHERE id = p_id LIMIT 1;

    IF v_exists IS NOT NULL THEN
        SQLCODE := '0';
        -- Statements for SQLCODE := '0';
    ELSE
        SQLCODE := '100';
        -- Statements for SQLCODE := '100';
    END IF;
EXCEPTION
    WHEN OTHERS THEN
        SQLCODE := SQLSTATE;
        -- Statements for other errors;
        ERR_MSG := SQLERRM;
END;
```

This approach ensures that an explicit check is performed before attempting an `INTO` operation, thus mitigating potential `NO_DATA_FOUND` errors. 

#### 5. Utilizing SQLSTATE for Error Handling

- SQLSTATE is a standardized code that indicates the outcome of SQL operations. It is crucial for identifying specific error conditions and implementing appropriate error handling mechanisms.

##### Example:

```sql
BEGIN
    -- SQL operation
EXCEPTION
    WHEN OTHERS THEN
        SQLCODE := SQLSTATE;
        ERR_MSG := SQLERRM;
END;
```

In this example, `SQLSTATE` captures the error code, and `SQLERRM` provides the error message. These values are assigned to `SQLCODE` and `ERR_MSG` respectively, allowing for detailed error diagnostics and logging.

#### 6. SQL Execution Diagnostics

- Use `GET DIAGNOSTICS` to retrieve row impact metrics for `INSERT` and `UPDATE` operations.

```sql
GET DIAGNOSTICS rec_exists = ROW_COUNT;

IF rec_exists > 0 THEN
    SQLCODE := '0';
ELSE
    SQLCODE := '100';
END IF;

```
This snippet demonstrates how `GET DIAGNOSTICS` can be used to capture the number of rows affected by an `INSERT` or `UPDATE` operation. The resulting row count is stored in `rec_exists`, which can then be used to determine the success or failure of the operation.

#### 7. Replacing Temporary Tables with Arrays

To avoid runtime errors associated with temporary tables, replace their usage with arrays in PostgreSQL. Arrays provide a more efficient and error-free way to handle temporary data within functions.

##### Example: DB2 Stored Procedure with Temporary Table

```sql
CREATE PROCEDURE SYSPROC.SP_TEMP_TABLE_SAMPLE (IN P_ID INT, OUT P_RESULT VARCHAR(50))
BEGIN
    DECLARE GLOBAL TEMPORARY TABLE SESSION.TEMP_USERS AS
    (SELECT NAME FROM SYSPROC.USERS WHERE ID = P_ID) WITH DATA;
    
    SELECT NAME INTO P_RESULT FROM SESSION.TEMP_USERS;
END;
```

##### Equivalent PostgreSQL Function Using Arrays

```sql
CREATE OR REPLACE FUNCTION tgabm10.sp_temp_table_sample(p_id INT, OUT p_result VARCHAR(50)) RETURNS RECORD AS $$
DECLARE
    temp_users TEXT[];
BEGIN
    SELECT ARRAY(SELECT name FROM tgabm10.users WHERE id = p_id) INTO temp_users;
    
    IF array_length(temp_users, 1) > 0 THEN
        p_result := temp_users[1];
    ELSE
        p_result := 'User Not Found';
    END IF;
END;
$$ LANGUAGE plpgsql;
```

In this conversion, the temporary table is replaced with an array (`temp_users`). The array is populated with the results of the query, and the first element is used to set the output parameter. This approach eliminates the need for temporary tables and reduces the risk of runtime errors.

#### 8. Replacing `DECLARE EXIT HANDLER FOR SQLEXCEPTION` with `BEGIN...EXCEPTION...END`

To replace `DECLARE EXIT HANDLER FOR SQLEXCEPTION` in DB2 with `BEGIN...EXCEPTION...END` in PostgreSQL, follow these steps:

1. Identify the DB2 stored procedure containing the `DECLARE EXIT HANDLER FOR SQLEXCEPTION`.
2. Replace the `DECLARE EXIT HANDLER FOR SQLEXCEPTION` block with a `BEGIN...EXCEPTION...END` block in PostgreSQL.
3. Ensure that the error handling logic within the `EXCEPTION` block matches the original DB2 logic.

##### Example: DB2 Stored Procedure with `DECLARE EXIT HANDLER FOR SQLEXCEPTION`

```sql
CREATE PROCEDURE SYSPROC.SP_SAMPLE (IN P_ID INT, OUT P_NAME VARCHAR(50))
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        SET P_NAME = 'Error Occurred';
    END;

    SELECT NAME INTO P_NAME FROM TGABM10.USERS WHERE ID = P_ID;
END;
```

##### Equivalent PostgreSQL Function with `BEGIN...EXCEPTION...END`

```sql
CREATE OR REPLACE FUNCTION tgabm10.sp_sample(p_id INT, OUT p_name VARCHAR(50)) RETURNS RECORD AS $$
BEGIN
    BEGIN
        SELECT name INTO p_name FROM tgabm10.users WHERE id = p_id;
    EXCEPTION
        WHEN OTHERS THEN
            p_name := 'Error Occurred';
    END;
END;
$$ LANGUAGE plpgsql;
```

This transformation ensures that the error handling mechanism in PostgreSQL is equivalent to the original DB2 logic, maintaining the integrity of the stored procedure's functionality.

#### 9. Replacing `DECLARE CONTINUE HANDLER FOR SQLSTATE '23505'` with `EXCEPTION WHEN UNIQUE_VIOLATION THEN`

To replace `DECLARE CONTINUE HANDLER FOR SQLSTATE '23505'` in DB2 with `EXCEPTION WHEN UNIQUE_VIOLATION THEN` in PostgreSQL, follow these steps:

1. Identify the DB2 stored procedure containing the `DECLARE CONTINUE HANDLER FOR SQLSTATE '23505'`.
2. Replace the `DECLARE CONTINUE HANDLER FOR SQLSTATE '23505'` block with an `EXCEPTION WHEN UNIQUE_VIOLATION THEN` block in PostgreSQL.
3. Ensure that the error handling logic within the `EXCEPTION` block matches the original DB2 logic.

##### Example: DB2 Stored Procedure with `DECLARE CONTINUE HANDLER FOR SQLSTATE '23505'`

```sql
CREATE PROCEDURE SYSPROC.SP_SAMPLE (IN P_ID INT, IN P_NAME VARCHAR(50))
BEGIN
    DECLARE CONTINUE HANDLER FOR SQLSTATE '23505'
    BEGIN
        -- Handle unique constraint violation
    END;

    INSERT INTO TGABM10.USERS (ID, NAME) VALUES (P_ID, P_NAME);
END;
```

##### Equivalent PostgreSQL Function with `EXCEPTION WHEN UNIQUE_VIOLATION THEN`

```sql
CREATE OR REPLACE FUNCTION tgabm10.sp_sample(p_id INT, p_name VARCHAR(50)) RETURNS VOID AS $$
BEGIN
    BEGIN
        INSERT INTO tgabm10.users (id, name) VALUES (p_id, p_name);
    EXCEPTION
        WHEN UNIQUE_VIOLATION THEN
            -- Handle unique constraint violation
        WHEN OTHERS THEN
            -- Handle other exceptions
    END;
END;
$$ LANGUAGE plpgsql;
```

This transformation ensures that the error handling mechanism in PostgreSQL is equivalent to the original DB2 logic, maintaining the integrity of the stored procedure's functionality.

## 4. Testing

### Localized Validation

- Deploy converted PostgreSQL functions in a controlled environment.
- Execute unit test cases to ensure correct parameter handling and data integrity.
- Document function execution times.
- Verify schema consistency between migrated and original database objects.

### 4.1 Data Type Consistency Check

To ensure that all columns have consistent data types throughout the database, you can use the following SQL queries:

#### SQL to Check Data Type Consistency

```sql
<<To be updated>>
```

This query checks for columns that have inconsistent data types across different tables in the `public` schema.

#### SQL to List Columns with Discrepancies

```sql
<<To be updated>>
```

This query lists all columns with data type discrepancies, providing details about the table name, column name, and data type.

These queries help identify and address data type inconsistencies, ensuring schema integrity across the database.

### 4.2 Usage of Personally Developed Review Tools

This module contains tools developed in Python for Streamlit web applications.
To use these tools, follow the steps below:

1. Install Python and the required packages listed in `requirements.txt`.
2. Use Visual Studio Code (VS Code) as the development environment.
3. Run the Streamlit applications using the command `streamlit run <your_app.py>`.

Make sure to have all dependencies installed and properly configured in your environment.

#### 1. SQLcheck

SQLcheck is a tool designed to facilitate the comparison of PostgreSQL functions with their corresponding DB2 stored procedures. It performs the following tasks:

- **Query Matching:** Compares each PostgreSQL function with its DB2 stored procedure and lists all matching queries.
- **Field Comparison:** Lists all the fields mentioned in both the PostgreSQL function and the DB2 stored procedure, along with the actual list of columns in the related tables.
- **Highlighting Discrepancies:** Highlights missed columns, mismatched columns, and differences in values used or assigned.

![SQLcheck](./attachments/image.png)

This tool helps ensure that the PostgreSQL functions accurately reflect the logic and structure of the original DB2 stored procedures, enabling developers to identify and rectify any discrepancies.

#### 2. e1func

e1func is a tool that assists in managing and deploying PostgreSQL functions. It provides the following features:

- **Directory Listing:** Lists all the subdirectories in the specified folder.
- **File Selection:** Lists all the files in the selected subdirectories with options to select all, deselect all, or flip selection for each subdirectory.
- **Grant Statements:** Checks, lists, and adds "GRANT EXECUTE ON FUNCTION" statements for each selected function.
- **SQL File Creation:** Combines all the selected functions and creates a single stitched SQL file to install the functions on any PostgreSQL server.

![e1func](./attachments/image.png)

This tool streamlines the process of managing and deploying PostgreSQL functions by automating the generation of grant statements and consolidated SQL files for installation.

#### 3. cpytool

cpytool is a synchronization tool for managing Git repositories and ensuring consistency across different directory structures. It offers the following functionalities:

- **Backup Creation:** Based on the `dirlst.csv` file, which lists the source and destination directories, it provides a button to backup the destination folders/files by creating zip archives.
- **Directory Clearing:** Provides a button to clear the destination directories for files to be replaced.
- **File Copying:** Provides a button to copy files from each source folder to the corresponding destination folder as listed in the `dirlst.csv` file.

![cpytool](./attachments/image.png)

This tool simplifies the process of synchronizing files and directories across different environments, ensuring consistency and integrity in the migration process.

#### 4. Excel-based Function Execution SQL Generator

This tool is designed to generate function execution SQL for DBeaver. It takes InMaps and Call templates with datatype casts as inputs and generates the function call SQL with proper typecasts for testing in DBeaver.

##### Steps to Use the Tool:

1. **Prepare InMaps and Call Templates:**
    - Obtain the datatype casts from DBeaver:
      - Right-click on the function in DBeaver.
      - Select `Generate SQL` -> `Call`.
      - Choose `Use explicit typecast`.
      - Copy the generated SQL.

2. **Input Data in Excel:**
    - Paste the inmap from java team at A1. (contents inside {})
    - Paste the call template from DBeaver at H1.

![Input Data](./attachments/image.png)

3. **Generate Function Call SQL:**
    - Copy Function execution statement from R1.

![Copy Data](./attachments/image.png)

4. **Execute in DBeaver:**
    - Paste it into DBeaver's SQL editor.
    - Execute the SQL to test the function.

##### Example:

| Function Name | Parameter Name | Data Type | Value  |
|---------------|----------------|-----------|--------|
| sp_sample     | p_id           | INT       | 1      |
| sp_sample     | p_name         | VARCHAR   | 'John' |

Generated SQL:
```sql
SELECT * FROM sp_sample(1::INT, 'John'::VARCHAR);
```

This tool simplifies the process of generating and testing function calls in DBeaver by automating the creation of SQL statements with proper typecasts.


These tools streamline the migration process, ensuring accuracy, efficiency, and consistency in the conversion and deployment of database functions. These tools help eliminate manual errors, making the process more reliable.

> **Note:** These tools are personally developed and are continuously updated for each new scenario encountered. As such, they may be far from perfection.

---

## 5. Troubleshooting and Optimization

### Common Issues and Remediation Strategies

1. **Syntax Discrepancies:** Address DB2-specific syntax differences by rewriting constructs in PL/pgSQL.
2. **Cursor Lifecycle Management:** Ensure cursors are properly opened, iterated, and deallocated.
3. **Error Code Mapping:** Align DB2 error codes with PostgreSQL equivalents.
4. **UUID Conversion Anomalies:** Validate UUID transformations to prevent implicit casting errors.

---

## 6. Function Descriptions

For a comprehensive list of all the created PostgreSQL functions along with their short descriptions, please refer to the [Function Descriptions Page](./Function_Descriptions.md). This page provides an overview of each function, including its purpose, parameters, and any relevant notes to aid in understanding and utilizing the functions effectively.

--- 

## 7. Conclusion

This document provides a structured and detailed steps followed for migrating DB2 stored procedures to PostgreSQL functions. It ensures seamless conversion while maintaining the functional integrity of database operations. By leveraging best practices in procedural transformation, error handling, and performance optimization, this approach minimizes risk and facilitates a smooth transition.

