CREATE OR REPLACE FUNCTION tgabm10.e3rp5191(
	IN_USER_ID CHAR(36),
	OUT SQLCODE_PARM CHAR(10),
	OUT RESP_CD CHAR(14),
	OUT RESP_MSG CHAR(100),
	OUT ERR_MSG CHAR(100),
	OUT RESULT_SET_1 REFCURSOR
) RETURNS RECORD AS $$
DECLARE
	SQLCODE CHAR(10);
	REC_EXISTS INTEGER;
	IN_USER_ID_UUID UUID;
	rec RECORD;
BEGIN
	IN_USER_ID_UUID := IN_USER_ID::UUID;

	BEGIN
		SQLCODE_PARM := '';
		RESP_CD := '';
		RESP_MSG := '';
		ERR_MSG := '';

		BEGIN
			SELECT 1 INTO REC_EXISTS
			FROM tgabm10.gabm_user
			WHERE user_id = IN_USER_ID_UUID
			AND act_in = 'Y'
			LIMIT 1;

			SQLCODE := '0';
		EXCEPTION
			WHEN OTHERS THEN
				SQLCODE := SQLSTATE;
				ERR_MSG := SQLERRM;
		END;

		IF REC_EXISTS IS NULL THEN
			SQLCODE := '100';
		END IF;

		CASE
			WHEN SQLCODE = '0' THEN
				RESP_CD := 'E35191001';
				RESP_MSG := 'USER ID FOUND.';
				SQLCODE_PARM := SQLCODE;
			WHEN SQLCODE = '100' THEN
				RESP_CD := 'E35191101';
				RESP_MSG := 'USER ID NOT FOUND.';
				SQLCODE_PARM := SQLCODE;
				RETURN;
			ELSE
				RESP_CD := 'E35191901';
				RESP_MSG := 'THE SYSTEM CANNOT PROCESS YOUR REQUEST. PLEASE TRY AFTER SOME TIME.';
				SQLCODE_PARM := SQLCODE;
				ERR_MSG := SQLERRM;
				RETURN;
		END CASE;

		BEGIN
			OPEN RESULT_SET_1 FOR
			SELECT 
				C.cmpgn_id,
				C.cmpgn_nm,
				C.cmpgn_ds,
				C.cmpgn_promo_cd,
				C.cmpgn_sta_tx,
				C.creat_ts,
				C.lst_updt_ts,
				C.cmpgn_contest_max_enter_ct,
				C.cmpgn_trgt_regis_ct,
				C.bus_prtr_drct_own_nm,
				C.cmpgn_strt_dt,
				C.cmpgn_end_dt,
				C.da_prg_dt,
				C.creat_by_user_type_tx,
				C.updt_by_user_type_tx,
				C.enroll_suc_email_send_in,
				C.enroll_suc_email_tmplt_id,
				C.enroll_sta_email_send_in,
				C.enroll_sta_email_tmplt_id,
				C.cmpgn_im_url_ad_1x,
				C.ems_extnl_promo_id,
				C.ems_extnl_prtr_id,
				C.cmpgn_live_dt,
				CC.iso_alpha_2_ctry_cd,
				CC.official_ctry_nm,
				CC.abbr_ctry_nm,
				CC.act_in,
				CC.creat_by_prcs_nm,
				CC.creat_ts,
				CC.lst_updt_by_prcs_nm,
				CC.lst_updt_ts
			FROM tgabm10.gabm_cmpgn C
			JOIN tgabm10.gabm_cmpgn_user_role CUR ON CUR.cmpgn_id = C.cmpgn_id
			JOIN tgabm10.gabm_cmpgn_ctry CC ON CC.cmpgn_id = C.cmpgn_id
			WHERE C.cmpgn_end_dt >= CURRENT_DATE
			AND CUR.user_id = IN_USER_ID_UUID
			AND CUR.act_in = 'Y'
			AND CC.act_in = 'Y';

			FETCH RESULT_SET_1 INTO rec;
			IF NOT FOUND THEN
				SQLCODE := '100';
			ELSE
				SQLCODE := '0';
			END IF;
		EXCEPTION
			WHEN OTHERS THEN
				SQLCODE := SQLSTATE;
				ERR_MSG := SQLERRM;
				RETURN;
		END;

		CASE
			WHEN SQLCODE = '0' THEN
				RESP_CD := 'E35191002';
				RESP_MSG := 'ACTIVE CMPGN DETAIL FETCH SUCCESSFULLY.';
				SQLCODE_PARM := SQLCODE;
				RETURN;
			ELSE
				RESP_CD := 'E35191902';
				RESP_MSG := 'THE SYSTEM CANNOT PROCESS YOUR REQUEST. PLEASE TRY AFTER SOME TIME.';
				SQLCODE_PARM := SQLCODE;
				ERR_MSG := SQLERRM;
				RETURN;
		END CASE;
	END;
EXCEPTION
    WHEN OTHERS THEN
        SQLCODE := SQLSTATE;
        SQLCODE_PARM := SQLCODE;
        RESP_CD := 'E35191999';
        RESP_MSG := 'SQL EXCEPTION.CHECK SQLCODE TO FIX.';
        ERR_MSG := SQLERRM;
        RETURN;
END;
$$ LANGUAGE plpgsql;
GRANT EXECUTE ON FUNCTION tgabm10.e3rp5191 TO gabmusr;