
CREATE OR REPLACE FUNCTION tgabm10.e3rp5040(
	IN_RWRD_ID CHAR(36),
	IN_APPL_CMPNT_ID CHAR(36),
	IN_ACT_IN CHAR(1),
	IN_CREAT_BY_PRCS_NM CHAR(255),
	IN_CREAT_TS TIMESTAMP,
	IN_LST_UPDT_BY_PRCS_NM CHAR(255),
	IN_LST_UPDT_TS TIMESTAMP,
	OUT SQLCODE_PARM CHAR(10),
	OUT RESP_CD CHAR(14),
	OUT RESP_MSG CHAR(100),
	OUT ERR_MSG CHAR(100)
) RETURNS RECORD AS $$
DECLARE
	SQLCODE CHAR(10);
	REC_EXISTS INTEGER;
	IN_RWRD_ID_UUID UUID;
	IN_APPL_CMPNT_ID_UUID UUID;
BEGIN
	IN_RWRD_ID_UUID := IN_RWRD_ID::UUID;
	IN_APPL_CMPNT_ID_UUID := IN_APPL_CMPNT_ID::UUID;

	SQLCODE_PARM := '';
	RESP_CD := '';
	RESP_MSG := '';
	ERR_MSG := '';

	IF IN_ACT_IN <> 'N' THEN
		BEGIN
			SELECT 1 INTO REC_EXISTS
			FROM tgabm10.gabm_rwrd
			WHERE rwrd_id = IN_RWRD_ID_UUID AND act_in = 'Y'
			LIMIT 1;

			IF REC_EXISTS IS NULL THEN
				RESP_CD := 'E35040100';
				RESP_MSG := 'NO ACTIVE REWARD FOUND.';
				SQLCODE_PARM := '100';
				RETURN;
			ELSE
				RESP_CD := 'E35040000';
				RESP_MSG := 'REWARD ID FOUND.';
				SQLCODE_PARM := '0';
			END IF;
		EXCEPTION
			WHEN OTHERS THEN
				SQLCODE_PARM := SQLSTATE;
				RESP_CD := 'E35040900';
				RESP_MSG := 'THE SYSTEM CANNOT PROCESS YOUR REQUEST. PLEASE TRY AFTER SOME TIME.';
				ERR_MSG := SQLERRM;
				RETURN;
		END;

		BEGIN
			SELECT 1 INTO REC_EXISTS
			FROM tgabm10.gabm_appl_cmpnt
			WHERE appl_cmpnt_id = IN_APPL_CMPNT_ID_UUID AND act_in = 'Y'
			LIMIT 1;

			IF REC_EXISTS IS NULL THEN
				RESP_CD := 'E35040101';
				RESP_MSG := 'NO ACTIVE APPL COMP ID FOUND.';
				SQLCODE_PARM := '100';
				RETURN;
			ELSE
                RESP_CD := 'E35040001';
				RESP_MSG := 'APPL COMP ID FOUND.';
				SQLCODE_PARM := '0';
			END IF;
		EXCEPTION
			WHEN OTHERS THEN
				SQLCODE_PARM := SQLSTATE;
				RESP_CD := 'E35040901';
				RESP_MSG := 'THE SYSTEM CANNOT PROCESS YOUR REQUEST. PLEASE TRY AFTER SOME TIME.';
				ERR_MSG := SQLERRM;
				RETURN;
		END;

		BEGIN
			SELECT 1 INTO REC_EXISTS
			FROM tgabm10.gabm_rwrd_appl_cmpnt
			WHERE rwrd_id = IN_RWRD_ID_UUID AND appl_cmpnt_id = IN_APPL_CMPNT_ID_UUID
			LIMIT 1;

			IF REC_EXISTS IS NOT NULL THEN
                BEGIN
                    UPDATE tgabm10.gabm_rwrd_appl_cmpnt
                    SET act_in = IN_ACT_IN,
                        lst_updt_by_prcs_nm = IN_LST_UPDT_BY_PRCS_NM,
                        lst_updt_ts = CURRENT_TIMESTAMP
                    WHERE rwrd_id = IN_RWRD_ID_UUID AND appl_cmpnt_id = IN_APPL_CMPNT_ID_UUID;

                    RESP_CD := 'E35040002';
                    RESP_MSG := 'APPL COMP DATA UPDATED SUCCESSFULLY';
                    SQLCODE_PARM := '0';
                    RETURN;
                EXCEPTION
                    WHEN OTHERS THEN
                        SQLCODE_PARM := SQLSTATE;
                        RESP_CD := 'E35040902';
                        RESP_MSG := 'THE SYSTEM CANNOT PROCESS YOUR REQUEST. PLEASE TRY AFTER SOME TIME.';
                        ERR_MSG := SQLERRM;
                        RETURN;
                END;
			ELSE
                BEGIN
                    INSERT INTO tgabm10.gabm_rwrd_appl_cmpnt (
                        rwrd_id, appl_cmpnt_id, act_in, creat_by_prcs_nm, creat_ts
                    ) VALUES (
                        IN_RWRD_ID_UUID, IN_APPL_CMPNT_ID_UUID, IN_ACT_IN, IN_CREAT_BY_PRCS_NM, CURRENT_TIMESTAMP
                    );

                    RESP_CD := 'E35040003';
                    RESP_MSG := 'APPL COMP DATA INSERTED SUCCESSFULLY';
                    SQLCODE_PARM := '0';
                    RETURN;
                EXCEPTION
                    WHEN OTHERS THEN
                        SQLCODE_PARM := SQLSTATE;
                        RESP_CD := 'E35040903';
                        RESP_MSG := 'THE SYSTEM CANNOT PROCESS YOUR REQUEST. PLEASE TRY AFTER SOME TIME.';
                        ERR_MSG := SQLERRM;
                        RETURN;
                END;
			END IF;
		END;
	ELSE
		BEGIN
			UPDATE tgabm10.gabm_rwrd_appl_cmpnt
			SET act_in = IN_ACT_IN,
				lst_updt_by_prcs_nm = IN_LST_UPDT_BY_PRCS_NM,
				lst_updt_ts = CURRENT_TIMESTAMP
			WHERE rwrd_id = IN_RWRD_ID_UUID;

			GET DIAGNOSTICS REC_EXISTS = ROW_COUNT;
			IF REC_EXISTS = 0 THEN
				RESP_CD := 'E35040104';
				RESP_MSG := 'APPL COMP DTL NOT FOUND.';
				SQLCODE_PARM := '100';
				RETURN;
			ELSE
				RESP_MSG := 'APPL COMP DATA UPDATED SUCCESSFULLY';
				SQLCODE_PARM := '0';
				RETURN;
			END IF;
		EXCEPTION
			WHEN OTHERS THEN
				SQLCODE_PARM := SQLSTATE;
				RESP_CD := 'E35040904';
				RESP_MSG := 'THE SYSTEM CANNOT PROCESS YOUR REQUEST. PLEASE TRY AFTER SOME TIME.';
				ERR_MSG := SQLERRM;
				RETURN;
		END;
	END IF;
EXCEPTION
	WHEN OTHERS THEN
		SQLCODE_PARM := SQLSTATE;
		RESP_CD := 'E35040999';
		RESP_MSG := 'SQL EXCEPTION.CHECK SQLCODE TO FIX.';
		ERR_MSG := SQLERRM;
		RETURN;
END;
$$ LANGUAGE plpgsql;
GRANT EXECUTE ON FUNCTION tgabm10.e3rp5040 TO gabmusr;