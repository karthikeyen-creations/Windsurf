CREATE OR REPLACE FUNCTION tgabm10.e3rp5169(
	IN_CMPGN_ID CHAR(36),
	IN_ISO_ALPHA_2_CTRY_CD CHAR(2),
	IN_OFFICIAL_CTRY_NM CHAR(40),
	IN_ABBR_CTRY_NM CHAR(10),
	IN_ACT_IN CHAR(1),
	IN_CREAT_BY_PRCS_NM CHAR(255),
	IN_LST_UPDT_BY_PRCS_NM CHAR(255),
	OUT SQLCODE_PARM CHAR(10),
	OUT RESP_CD CHAR(14),
	OUT RESP_MSG CHAR(100),
	OUT ERR_MSG CHAR(100)
) RETURNS RECORD AS $$
DECLARE
	IN_CMPGN_ID_UUID UUID;
	SQLCODE CHAR(10);
	REC_EXISTS INTEGER;
BEGIN
	IN_CMPGN_ID_UUID := IN_CMPGN_ID::UUID;
	SQLCODE_PARM := '';
	RESP_CD := '';
	RESP_MSG := '';
	ERR_MSG := '';

	BEGIN
		SELECT 1 INTO REC_EXISTS
		FROM tgabm10.gabm_cmpgn
		WHERE cmpgn_id = IN_CMPGN_ID_UUID
		AND cmpgn_end_dt >= CURRENT_DATE
		LIMIT 1;

		IF REC_EXISTS IS NOT NULL THEN
			RESP_CD := 'E35169001';
			RESP_MSG := 'CAMPAIGN ID FOUND.';
			SQLCODE_PARM := '0';
		ELSE
			RESP_CD := 'E35169101';
			RESP_MSG := 'NO ACTIVE CAMPAIGN FOUND.';
			SQLCODE_PARM := '100';
			RETURN;
		END IF;
	EXCEPTION
		WHEN OTHERS THEN
			SQLCODE_PARM := SQLSTATE;
			RESP_CD := 'E35169901';
			RESP_MSG := 'THE SYSTEM CANNOT PROCESS YOUR REQUEST. PLEASE TRY AFTER SOME TIME.';
			ERR_MSG := SQLERRM;
			RETURN;
	END;

	BEGIN
		IF EXISTS(
			SELECT 1
			FROM tgabm10.gabm_cmpgn_ctry
			WHERE cmpgn_id = IN_CMPGN_ID_UUID
			AND iso_alpha_2_ctry_cd = IN_ISO_ALPHA_2_CTRY_CD
			LIMIT 1
		) THEN
            BEGIN
                UPDATE tgabm10.gabm_cmpgn_ctry
                SET official_ctry_nm = IN_OFFICIAL_CTRY_NM,
                    abbr_ctry_nm = IN_ABBR_CTRY_NM,
                    act_in = IN_ACT_IN,
                    lst_updt_by_prcs_nm = IN_LST_UPDT_BY_PRCS_NM,
                    lst_updt_ts = CURRENT_TIMESTAMP
                WHERE cmpgn_id = IN_CMPGN_ID_UUID
                AND iso_alpha_2_ctry_cd = IN_ISO_ALPHA_2_CTRY_CD;

                RESP_CD := 'E35169002';
                RESP_MSG := 'CMPGN CTRY TBL UPDATED SUCCESSFULLY';
                SQLCODE_PARM := '0';
                RETURN;
            EXCEPTION WHEN OTHERS THEN
                SQLCODE_PARM := SQLSTATE;
                RESP_CD := 'E35169902';
                RESP_MSG := 'THE SYSTEM CANNOT PROCESS YOUR REQUEST. PLEASE TRY AFTER SOME TIME.';
                ERR_MSG := SQLERRM;
                RETURN;
            END;
		ELSE
            BEGIN
                INSERT INTO tgabm10.gabm_cmpgn_ctry (
                    cmpgn_id,
                    iso_alpha_2_ctry_cd,
                    official_ctry_nm,
                    abbr_ctry_nm,
                    act_in,
                    creat_by_prcs_nm,
                    creat_ts,
                    lst_updt_by_prcs_nm,
                    lst_updt_ts
                ) VALUES (
                    IN_CMPGN_ID_UUID,
                    IN_ISO_ALPHA_2_CTRY_CD,
                    IN_OFFICIAL_CTRY_NM,
                    IN_ABBR_CTRY_NM,
                    IN_ACT_IN,
                    IN_CREAT_BY_PRCS_NM,
                    CURRENT_TIMESTAMP,
                    IN_LST_UPDT_BY_PRCS_NM,
                    CURRENT_TIMESTAMP
                );

                RESP_CD := 'E35169003';
                RESP_MSG := 'CMPGN CTRY DTL INSERTED SUCCESSFULLY.';
                SQLCODE_PARM := '0';
                RETURN;
            EXCEPTION WHEN OTHERS THEN
                SQLCODE_PARM := SQLSTATE;
                RESP_CD := 'E35169903';
                RESP_MSG := 'THE SYSTEM CANNOT PROCESS YOUR REQUEST. PLEASE TRY AFTER SOME TIME.';
                ERR_MSG := SQLERRM;
                RETURN;
            END;
		END IF;
	END;
EXCEPTION
    WHEN OTHERS THEN
        SQLCODE_PARM := SQLSTATE;
        RESP_CD := 'E35169999';
        RESP_MSG := 'SQL EXCEPTION. CHECK SQLCODE TO FIX.';
        ERR_MSG := SQLERRM;
        RETURN;
END;
$$ LANGUAGE plpgsql;
GRANT EXECUTE ON FUNCTION tgabm10.e3rp5169 TO gabmusr;