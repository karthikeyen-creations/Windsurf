CREATE OR REPLACE FUNCTION tgabm10.e3rp5180(
    IN_RDM_TRANS_ID CHAR(36),
    IN_CMPGN_ID CHAR(36),
    IN_RDM_STA_CD CHAR(50),
    IN_COMPAN_CT SMALLINT,
    IN_RDM_CARD_TYPE_CD CHAR(64),
    IN_PTCP_ID CHAR(36),
    IN_RDM_ID CHAR(36),
    IN_ACT_IN CHAR(1),
    IN_RWRD_ID CHAR(25),
    IN_CREAT_BY_PRCS_NM CHAR(255),
    IN_LST_UPDT_BY_PRCS_NM CHAR(255),
    OUT SQLCODE_PARM CHAR(10),
    OUT RESP_CD CHAR(14),
    OUT RESP_MSG CHAR(100),
    OUT ERR_MSG CHAR(100)
) RETURNS RECORD AS $$
DECLARE
    SQLCODE CHAR(10);
    REC_EXISTS INTEGER;
    HV_RDM_STA_ID SMALLINT;
    IN_RDM_TRANS_ID_UUID UUID;
    IN_CMPGN_ID_UUID UUID;
    IN_PTCP_ID_UUID UUID;
    IN_RDM_ID_UUID UUID;
BEGIN
    IN_RDM_TRANS_ID_UUID := IN_RDM_TRANS_ID::UUID;
    IN_CMPGN_ID_UUID := IN_CMPGN_ID::UUID;
    IN_PTCP_ID_UUID := IN_PTCP_ID::UUID;
    IN_RDM_ID_UUID := IN_RDM_ID::UUID;

    SQLCODE_PARM := '';
    RESP_CD := '';
    RESP_MSG := '';
    ERR_MSG := '';

    -- VERIFY IF CAMPAIGN EXIST AND IS ACTIVE.
    BEGIN
        SELECT 1 INTO REC_EXISTS
        FROM tgabm10.gabm_cmpgn
        WHERE cmpgn_id = IN_CMPGN_ID_UUID
        AND cmpgn_end_dt >= CURRENT_DATE
        LIMIT 1;

        IF REC_EXISTS IS NULL THEN
            SQLCODE := '100';
        ELSE
            SQLCODE := '0';
        END IF;

        IF SQLCODE = '0' THEN
            RESP_CD := 'E35180000';
            RESP_MSG := 'CAMPAIGN ID FOUND.';
            SQLCODE_PARM := SQLCODE;
        ELSE
            RESP_CD := 'E35180100';
            RESP_MSG := 'NO ACTIVE CAMPAIGN FOUND.';
            SQLCODE_PARM := SQLCODE;
            RETURN;
        END IF;
    EXCEPTION
        WHEN OTHERS THEN
            SQLCODE := SQLSTATE;
            SQLCODE_PARM := SQLCODE;
            RESP_CD := 'E35180900';
            RESP_MSG := 'THE SYSTEM CANNOT PROCESS YOUR REQUEST. PLEASE TRY AFTER SOME TIME.';
            ERR_MSG := SQLERRM;
            RETURN;
    END;

    -- VERIFY IF PTCP ID EXISTS.
    IF IN_PTCP_ID <> '' THEN
        BEGIN
            SELECT 1 INTO REC_EXISTS
            FROM tgabm10.gabm_ptcp
            WHERE ptcp_id = IN_PTCP_ID_UUID
            AND act_in = 'Y'
            AND rwrd_id = IN_RWRD_ID
            LIMIT 1;

            IF REC_EXISTS IS NULL THEN
                SQLCODE := '100';
            ELSE
                SQLCODE := '0';
            END IF;

            IF SQLCODE = '0' THEN
                RESP_CD := 'E35180001';
                RESP_MSG := 'PTCP ID FOUND.';
                SQLCODE_PARM := SQLCODE;
            ELSE
                RESP_CD := 'E35180101';
                RESP_MSG := 'PTCP ID NOT FOUND.';
                SQLCODE_PARM := SQLCODE;
                RETURN;
            END IF;
        EXCEPTION
            WHEN OTHERS THEN
                SQLCODE := SQLSTATE;
                SQLCODE_PARM := SQLCODE;
                RESP_CD := 'E35180901';
                RESP_MSG := 'THE SYSTEM CANNOT PROCESS YOUR REQUEST. PLEASE TRY AFTER SOME TIME.';
                ERR_MSG := SQLERRM;
                RETURN;
        END;
    END IF;

    -- VERIFY IF RDM STA CD EXISTS
    BEGIN
        SELECT rdm_sta_id INTO HV_RDM_STA_ID
        FROM tgabm10.gabm_rdm_sta
        WHERE rdm_sta_cd = IN_RDM_STA_CD
        LIMIT 1;

        IF HV_RDM_STA_ID IS NULL THEN
            SQLCODE := '100';
        ELSE
            SQLCODE := '0';
        END IF;

        IF SQLCODE = '0' THEN
            RESP_CD := 'E35180002';
            RESP_MSG := 'RDM STA CD FOUND.';
            SQLCODE_PARM := SQLCODE;
        ELSE
            RESP_CD := 'E35180102';
            RESP_MSG := 'RDM STA CD NOT FOUND.';
            SQLCODE_PARM := SQLCODE;
            RETURN;
        END IF;
    EXCEPTION
        WHEN OTHERS THEN
            SQLCODE := SQLSTATE;
            SQLCODE_PARM := SQLCODE;
            RESP_CD := 'E35180902';
            RESP_MSG := 'THE SYSTEM CANNOT PROCESS YOUR REQUEST. PLEASE TRY AFTER SOME TIME.';
            ERR_MSG := SQLERRM;
            RETURN;
    END;

    -- VERIFY IF RDM ID EXISTS
    BEGIN
        SELECT 1 INTO REC_EXISTS
        FROM tgabm10.gabm_rdm
        WHERE rdm_id = IN_RDM_ID_UUID
        AND ptcp_id = IN_PTCP_ID_UUID
        LIMIT 1;

        IF REC_EXISTS IS NULL THEN
            SQLCODE := '100';
        ELSE
            SQLCODE := '0';
        END IF;

        IF SQLCODE = '0' THEN
            RESP_CD := 'E35180003';
            RESP_MSG := 'RDM ID FOUND.';
            SQLCODE_PARM := SQLCODE;
        ELSE
            RESP_CD := 'E35180103';
            RESP_MSG := 'RDM ID NOT FOUND.';
            SQLCODE_PARM := SQLCODE;
            RETURN;
        END IF;
    EXCEPTION
        WHEN OTHERS THEN
            SQLCODE := SQLSTATE;
            SQLCODE_PARM := SQLCODE;
            RESP_CD := 'E35180903';
            RESP_MSG := 'THE SYSTEM CANNOT PROCESS YOUR REQUEST. PLEASE TRY AFTER SOME TIME.';
            ERR_MSG := SQLERRM;
            RETURN;
    END;

    -- INSERT INTO GABM_CMPGN_RDM_TRANS TABLE
    BEGIN
        INSERT INTO tgabm10.gabm_cmpgn_rdm_trans (
            rdm_trans_id, cmpgn_id, rdm_sta_id, in_compan_ct, rdm_card_type_cd, ptcp_id,
            rdm_id, prg_in, act_in, creat_by_prcs_nm, creat_ts, lst_updt_by_prcs_nm, lst_updt_ts
        ) VALUES (
            IN_RDM_TRANS_ID_UUID, IN_CMPGN_ID_UUID, HV_RDM_STA_ID, IN_COMPAN_CT, IN_RDM_CARD_TYPE_CD, IN_PTCP_ID_UUID,
            IN_RDM_ID_UUID, 'Y', IN_ACT_IN, IN_CREAT_BY_PRCS_NM, CURRENT_TIMESTAMP, IN_LST_UPDT_BY_PRCS_NM, CURRENT_TIMESTAMP
        );

        SQLCODE := '0';
        RESP_CD := 'E35180004';
        RESP_MSG := 'RDM TRANS INSERTED SUCCESSFULLY.';
        SQLCODE_PARM := SQLCODE;
    EXCEPTION
        WHEN unique_violation THEN
            SQLCODE := '-803';
            RESP_CD := 'E35180204';
            RESP_MSG := 'DUPLICATE RDM TRANS ID. INSERT FAILED.';
            SQLCODE_PARM := SQLCODE;
            ERR_MSG := SQLERRM;
            RETURN;
        WHEN OTHERS THEN
            SQLCODE := SQLSTATE;
            SQLCODE_PARM := SQLCODE;
            RESP_CD := 'E35180904';
            RESP_MSG := 'THE SYSTEM CANNOT PROCESS YOUR REQUEST. PLEASE TRY AFTER SOME TIME.';
            ERR_MSG := SQLERRM;
            RETURN;
    END;

    RETURN;
EXCEPTION
    WHEN OTHERS THEN
        SQLCODE := SQLSTATE;
        SQLCODE_PARM := SQLCODE;
        RESP_CD := 'E35180999';
        RESP_MSG := 'THE SYSTEM CANNOT PROCESS YOUR REQUEST. PLEASE TRY AFTER SOME TIME.';
        ERR_MSG := SQLERRM;
        RETURN;
END;
$$ LANGUAGE plpgsql;
GRANT EXECUTE ON FUNCTION tgabm10.e3rp5180 TO gabmusr;