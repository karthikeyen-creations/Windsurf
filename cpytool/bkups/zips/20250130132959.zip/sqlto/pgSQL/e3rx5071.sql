CREATE OR REPLACE FUNCTION tgabm10.e3rx5071(
	IN_APPL_CMPNT_ID CHAR(36),
	IN_APPL_CMPNT_CD CHAR(254),
	IN_APPL_CMPNT_NM CHAR(254),
	IN_APPL_CMPNT_DS VARCHAR(500),
	IN_ACT_IN CHAR(1),
	IN_CREAT_BY_PRCS_NM CHAR(255),
	IN_LST_UPDT_BY_PRCS_NM CHAR(255),
	IN_CMPNT_TYPE_DS CHAR(25),
	OUT SQLCODE_PARM CHAR(10),
	OUT RESP_CD CHAR(14),
	OUT RESP_MSG CHAR(100),
	OUT ERR_MSG CHAR(100)
) RETURNS RECORD AS $$
DECLARE
	IN_APPL_CMPNT_ID_UUID UUID;
	SQLCODE CHAR(10);
	REC_EXISTS INTEGER;
BEGIN
	IN_APPL_CMPNT_ID_UUID := IN_APPL_CMPNT_ID::UUID;

	SQLCODE_PARM := '';
	RESP_CD := '';
	RESP_MSG := '';
	ERR_MSG := '';

	-- CHECK IF APPL COMP ID EXISTS
	-- 1) IF EXISTS , UPDATE THE APPL COMP DTL.
	-- 2) IF NOT, INSERT THE NEW APPL COMP DTL.

	BEGIN
		SELECT 1 INTO REC_EXISTS
		FROM tgabm10.gabm_appl_cmpnt
		WHERE appl_cmpnt_id = IN_APPL_CMPNT_ID_UUID
		LIMIT 1;

		IF REC_EXISTS IS NOT NULL THEN
			BEGIN
				UPDATE tgabm10.gabm_appl_cmpnt
				SET appl_cmpnt_cd = IN_APPL_CMPNT_CD,
					appl_cmpnt_nm = IN_APPL_CMPNT_NM,
					appl_cmpnt_ds = IN_APPL_CMPNT_DS,
					act_in = IN_ACT_IN,
					lst_updt_by_prcs_nm = IN_LST_UPDT_BY_PRCS_NM,
					lst_updt_ts = CURRENT_TIMESTAMP,
					cmpnt_type_ds = IN_CMPNT_TYPE_DS
				WHERE appl_cmpnt_id = IN_APPL_CMPNT_ID_UUID;

                GET DIAGNOSTICS REC_EXISTS = ROW_COUNT;
                IF REC_EXISTS = 0 THEN
                    SQLCODE := '100';
                    RESP_CD := 'E35071901';
				    RESP_MSG := 'THE SYSTEM CANNOT PROCESS YOUR REQUEST. PLEASE TRY AFTER SOME TIME.';
                    RETURN;
                ELSE
                    SQLCODE := '0';
                    RESP_CD := 'E35071001';
                    RESP_MSG := 'APPL COMP DTL UPDATED SUCCESSFULLY';
                    RETURN;
                END IF;
                SQLCODE_PARM := SQLCODE;
                RETURN;
			EXCEPTION WHEN OTHERS THEN
				SQLCODE := SQLSTATE;
				RESP_CD := 'E35071901';
				RESP_MSG := 'THE SYSTEM CANNOT PROCESS YOUR REQUEST. PLEASE TRY AFTER SOME TIME.';
				SQLCODE_PARM := SQLCODE;
				ERR_MSG := SQLERRM;
				RETURN;
			END;
		ELSE
			BEGIN
				INSERT INTO tgabm10.gabm_appl_cmpnt (
					appl_cmpnt_id,
					appl_cmpnt_cd,
					appl_cmpnt_nm,
					appl_cmpnt_ds,
					act_in,
					creat_by_prcs_nm,
					creat_ts,
					lst_updt_by_prcs_nm,
					lst_updt_ts,
					cmpnt_type_ds
				) VALUES (
					IN_APPL_CMPNT_ID_UUID,
					IN_APPL_CMPNT_CD,
					IN_APPL_CMPNT_NM,
					IN_APPL_CMPNT_DS,
					IN_ACT_IN,
					IN_CREAT_BY_PRCS_NM,
					CURRENT_TIMESTAMP,
					IN_LST_UPDT_BY_PRCS_NM,
					CURRENT_TIMESTAMP,
					IN_CMPNT_TYPE_DS
				);
                GET DIAGNOSTICS REC_EXISTS = ROW_COUNT;
                IF REC_EXISTS = 0 THEN
                    SQLCODE := '100';
                    RESP_CD := 'E35071902';
                    RESP_MSG := 'THE SYSTEM CANNOT PROCESS YOUR REQUEST. PLEASE TRY AFTER SOME TIME.';
                    RETURN;
                ELSE
                    SQLCODE := '0';
                    RESP_CD := 'E35071002';
                    RESP_MSG := 'APPL COMP DTL INSERTED SUCCESSFULLY';
                    RETURN;
                END IF;
                SQLCODE_PARM := SQLCODE;
                RETURN;
			EXCEPTION WHEN OTHERS THEN
				SQLCODE := SQLSTATE;
				RESP_CD := 'E35071902';
				RESP_MSG := 'THE SYSTEM CANNOT PROCESS YOUR REQUEST. PLEASE TRY AFTER SOME TIME.';
				SQLCODE_PARM := SQLCODE;
				ERR_MSG := SQLERRM;
				RETURN;
			END;
		END IF;
	EXCEPTION WHEN OTHERS THEN
		SQLCODE := SQLSTATE;
		RESP_CD := 'E35071999';
		RESP_MSG := 'SQL EXCEPTION.CHECK SQLCODE TO FIX.';
		SQLCODE_PARM := SQLCODE;
		ERR_MSG := SQLERRM;
		RETURN;
	END;
END;
$$ LANGUAGE plpgsql;
GRANT EXECUTE ON FUNCTION tgabm10.e3rx5071 TO gabmusr;