CREATE OR REPLACE FUNCTION tgabm10.e3rx5068(
	IN_RWRD_ID CHAR(36),
	IN_RWRD_NM CHAR(254),
	IN_RWRD_DS VARCHAR(500),
	IN_RDM_LMT_CT SMALLINT,
	IN_ACT_IN CHAR(1),
	IN_CREAT_BY_PRCS_NM CHAR(255),
	IN_CREAT_TS TIMESTAMP,
	IN_LST_UPDT_BY_PRCS_NM CHAR(255),
	IN_LST_UPDT_TS TIMESTAMP,
	IN_RWRD_CLASS_CD SMALLINT,
	IN_RWRD_CMNT_TX VARCHAR(1024),
	IN_RWRD_DTL_DS VARCHAR(1024),
	IN_RWRD_NTFY_TX VARCHAR(1024),
	IN_RWRD_GRP_NM CHAR(64),
	IN_RWRD_DISP_SEQ_NO SMALLINT,
	OUT SQLCODE_PARM CHAR(10),
	OUT RESP_CD CHAR(14),
	OUT RESP_MSG CHAR(100),
	OUT ERR_MSG CHAR(100)
) RETURNS RECORD AS $$
DECLARE
	SQLCODE CHAR(10);
	REC_EXISTS INTEGER;
	IN_RWRD_ID_UUID UUID;
BEGIN
	IN_RWRD_ID_UUID := IN_RWRD_ID::UUID;
	SQLCODE_PARM := '';
	RESP_CD := '';
	RESP_MSG := '';
	ERR_MSG := '';

	BEGIN
		SELECT 1 INTO REC_EXISTS
		FROM tgabm10.gabm_rwrd_class
		WHERE rwrd_class_cd = IN_RWRD_CLASS_CD
		AND act_in = 'Y'
		LIMIT 1;

		IF REC_EXISTS IS NOT NULL THEN
			RESP_CD := 'E35068003';
			RESP_MSG := 'CLASS CD FOUND.';
			SQLCODE_PARM := '0';
		ELSE
			RESP_CD := 'E35068103';
			RESP_MSG := 'NO ACTIVE CLASS CD FOUND.';
			SQLCODE_PARM := '100';
			RETURN;
		END IF;
	EXCEPTION
		WHEN OTHERS THEN
			SQLCODE_PARM := SQLSTATE;
			RESP_CD := 'E35068903';
			RESP_MSG := 'THE SYSTEM CANNOT PROCESS YOUR REQUEST. PLEASE TRY AFTER SOME TIME.';
			ERR_MSG := SQLERRM;
			RETURN;
	END;

	BEGIN
		IF EXISTS (SELECT 1 FROM tgabm10.gabm_rwrd WHERE rwrd_id = IN_RWRD_ID_UUID) THEN
        BEGIN
            UPDATE tgabm10.gabm_rwrd
            SET rwrd_nm = IN_RWRD_NM,
                rwrd_ds = IN_RWRD_DS,
                rdm_lmt_ct = IN_RDM_LMT_CT,
                act_in = IN_ACT_IN,
                lst_updt_by_prcs_nm = IN_LST_UPDT_BY_PRCS_NM,
                lst_updt_ts = CURRENT_TIMESTAMP,
                rwrd_class_cd = IN_RWRD_CLASS_CD,
                rwrd_dtl_ds = IN_RWRD_DTL_DS,
                rwrd_cmnt_tx = IN_RWRD_CMNT_TX,
                rwrd_ntfy_tx = IN_RWRD_NTFY_TX,
                rwrd_grp_nm = IN_RWRD_GRP_NM,
                rwrd_disp_seq_no = IN_RWRD_DISP_SEQ_NO
            WHERE rwrd_id = IN_RWRD_ID_UUID;

            GET DIAGNOSTICS REC_EXISTS = ROW_COUNT;

            IF REC_EXISTS > 0 THEN
                RESP_CD := 'E35068001';
                RESP_MSG := 'RWRD ID SUCCESSFULLY UPDATED.';
                SQLCODE_PARM := '0';
            ELSE
                RESP_CD := 'E35068901';
                RESP_MSG := 'THE SYSTEM CANNOT PROCESS YOUR REQUEST. PLEASE TRY AFTER SOME TIME.';
                SQLCODE_PARM := '100';
            END IF;
        EXCEPTION
            WHEN OTHERS THEN
                SQLCODE_PARM := SQLSTATE;
                RESP_CD := 'E35068901';
                RESP_MSG := 'THE SYSTEM CANNOT PROCESS YOUR REQUEST. PLEASE TRY AFTER SOME TIME.';
                ERR_MSG := SQLERRM;
                RETURN;
        END;	
        ELSE
        BEGIN
            INSERT INTO tgabm10.gabm_rwrd (
                rwrd_id, rwrd_nm, rwrd_ds, rdm_lmt_ct, act_in, creat_by_prcs_nm, creat_ts,
                lst_updt_by_prcs_nm, lst_updt_ts, rwrd_class_cd, rwrd_cmnt_tx, rwrd_dtl_ds,
                rwrd_ntfy_tx, rwrd_grp_nm, rwrd_disp_seq_no
            ) VALUES (
                IN_RWRD_ID_UUID, IN_RWRD_NM, IN_RWRD_DS, IN_RDM_LMT_CT, IN_ACT_IN,
                IN_CREAT_BY_PRCS_NM, CURRENT_TIMESTAMP, IN_LST_UPDT_BY_PRCS_NM,
                CURRENT_TIMESTAMP, IN_RWRD_CLASS_CD, IN_RWRD_CMNT_TX, IN_RWRD_DTL_DS,
                IN_RWRD_NTFY_TX, IN_RWRD_GRP_NM, IN_RWRD_DISP_SEQ_NO
            );

            GET DIAGNOSTICS REC_EXISTS = ROW_COUNT;

            IF REC_EXISTS > 0 THEN
                RESP_CD := 'E35068002';
                RESP_MSG := 'RWRD ID SUCCESSFULLY INSERTED.';
                SQLCODE_PARM := '0';
            ELSE
                RESP_CD := 'E35068902';
                RESP_MSG := 'THE SYSTEM CANNOT PROCESS YOUR REQUEST. PLEASE TRY AFTER SOME TIME.';
                SQLCODE_PARM := '100';
            END IF;
        EXCEPTION
            WHEN OTHERS THEN
                SQLCODE_PARM := SQLSTATE;
                RESP_CD := 'E35068902';
                RESP_MSG := 'THE SYSTEM CANNOT PROCESS YOUR REQUEST. PLEASE TRY AFTER SOME TIME.';
                ERR_MSG := SQLERRM;
                RETURN;
        END;
		END IF;
	EXCEPTION
		WHEN OTHERS THEN
			SQLCODE_PARM := SQLSTATE;
			RESP_CD := 'E35068902';
			RESP_MSG := 'THE SYSTEM CANNOT PROCESS YOUR REQUEST. PLEASE TRY AFTER SOME TIME.';
			ERR_MSG := SQLERRM;
			RETURN;
	END;

	RETURN;
EXCEPTION
    WHEN OTHERS THEN
        SQLCODE_PARM := SQLSTATE;
        RESP_CD := 'E35068999';
        RESP_MSG := 'SQL EXCEPTION. CHECK SQLCODE TO FIX.';
        ERR_MSG := SQLERRM;
END;
$$ LANGUAGE plpgsql;


GRANT EXECUTE ON FUNCTION tgabm10.e3rx5068 TO gabmusr;