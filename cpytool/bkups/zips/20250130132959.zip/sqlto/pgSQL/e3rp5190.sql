CREATE OR REPLACE FUNCTION tgabm10.e3rp5190(
    IN_RDM_ID CHAR(36),
    IN_RDM_TYPE_CD CHAR(50),
    IN_ACT_IN CHAR(1),
    IN_CREAT_BY_PRCS_NM CHAR(255),
    IN_UPDT_BY_PRCS_NM CHAR(255),
    IN_PTCP_ID CHAR(64),
    IN_RDM_SUB_TYPE_DS CHAR(64),
    IN_RDM_CD CHAR(64),
    IN_RWRD_ID CHAR(36),
    OUT_RDM_ID CHAR(64),
    SQLCODE_PARM CHAR(10),
    RESP_CD CHAR(14),
    RESP_MSG CHAR(100),
    ERR_MSG CHAR(100)
) RETURNS RECORD AS $$
DECLARE
    SQLCODE CHAR(10);
    REC_EXISTS INTEGER;
    RDM_TYPE_ID_TEMP SMALLINT;
    IN_RDM_ID_UUID UUID;
    IN_RWRD_ID_UUID UUID;
    P1_UPDATE BOOLEAN;
BEGIN
    IN_RDM_ID_UUID := IN_RDM_ID::UUID;
    IN_RWRD_ID_UUID := IN_RWRD_ID::UUID;

    P1_UPDATE := TRUE;

    OUT_RDM_ID  := '';
    SQLCODE_PARM    := '';
    RESP_CD := '';
    RESP_MSG    := '';
    ERR_MSG := '';

    BEGIN
        SELECT RDM_TYPE_ID INTO RDM_TYPE_ID_TEMP
        FROM tgabm10.gabm_rdm_type
        WHERE RDM_TYPE_CD = IN_RDM_TYPE_CD AND ACTIN = 'Y'
        LIMIT 1;

        IF RDM_TYPE_ID_TEMP IS NULL THEN
            SQLCODE := '100';
        ELSE
            SQLCODE := '0';
        END IF;

        IF SQLCODE = '0' THEN
            RESP_CD := 'E35190000';
            RESP_MSG := 'REDEMPTION CD FOUND.';
            SQLCODE_PARM := SQLCODE;
        ELSE
            RESP_CD := 'E35190100';
            RESP_MSG := 'INVALID REDEMPTION TYPE CD.';
            SQLCODE_PARM := SQLCODE;
            RETURN;
        END IF;
    EXCEPTION
        WHEN OTHERS THEN
            SQLCODE_PARM := SQLCODE;
            RESP_CD := 'E35190900';
            RESP_MSG := 'THE SYSTEM CANNOT PROCESS YOUR REQUEST. PLEASE TRY AFTER SOME TIME.';
            ERR_MSG := SQLERRM;
            RETURN;
    END;

    BEGIN
        SELECT 1 INTO REC_EXISTS
        FROM tgabm10.gabm_ptcp
        WHERE PTCP_ID = IN_PTCP_ID AND RWRD_ID = IN_RWRD_ID_UUID AND ACTIN = 'Y'
        LIMIT 1;

        IF REC_EXISTS IS NULL THEN
            SQLCODE := '100';
        ELSE
            SQLCODE := '0';
        END IF;

        IF SQLCODE = '0' THEN
            RESP_CD := 'E35190001';
            RESP_MSG := 'ACTIVE PARTICIPANT FOUND.';
            SQLCODE_PARM := SQLCODE;
        ELSE
            RESP_CD := 'E35190101';
            RESP_MSG := 'NO ACTIVE PARTICIPANT FOUND.';
            SQLCODE_PARM := SQLCODE;
            RETURN;
        END IF;
    EXCEPTION
        WHEN OTHERS THEN
            SQLCODE_PARM := SQLCODE;
            RESP_CD := 'E35190901';
            RESP_MSG := 'THE SYSTEM CANNOT PROCESS YOUR REQUEST. PLEASE TRY AFTER SOME TIME.';
            ERR_MSG := SQLERRM;
            RETURN;
    END;

    BEGIN
        SELECT RDM_ID INTO OUT_RDM_ID
        FROM tgabm10.gabm_rdm
        WHERE RDM_CD = IN_RDM_CD AND RDM_TYPE_ID = RDM_TYPE_ID_TEMP
        LIMIT 1;

        IF OUT_RDM_ID IS NULL THEN
            SQLCODE := '100';
        ELSE
            SQLCODE := '0';
        END IF;

        IF SQLCODE = '0' THEN
            P1_UPDATE := FALSE;
        ELSE
            RESP_CD := 'E35190102';
            RESP_MSG := 'NO REDEMPTION FOR THIS PARTICIPANT.';
            SQLCODE_PARM := SQLCODE;
        END IF;
    EXCEPTION
        WHEN OTHERS THEN
            SQLCODE_PARM := SQLCODE;
            RESP_CD := 'E35190902';
            RESP_MSG := 'THE SYSTEM CANNOT PROCESS YOUR REQUEST. PLEASE TRY AFTER SOME TIME.';
            ERR_MSG := SQLERRM;
            RETURN;
    END;

    if(P1_UPDATE) then
        BEGIN
            INSERT INTO tgabm10.gabm_rdm (
                RDM_ID, RDM_CD, RDM_TYPE_ID, ACT_IN, CREAT_BY_PRCS_NM, CREAT_TS, LST_UPDT_BY_PRCS_NM, LST_UPDT_TS, PTCP_ID, RDM_SUB_TYPE_DS
            ) VALUES (
                IN_RDM_ID_UUID, IN_RDM_CD, RDM_TYPE_ID_TEMP, IN_ACT_IN, IN_CREAT_BY_PRCS_NM, CURRENT_TIMESTAMP, IN_UPDT_BY_PRCS_NM, CURRENT_TIMESTAMP, IN_PTCP_ID, IN_RDM_SUB_TYPE_DS
            );
            GET DIAGNOSTICS SQLCODE = ROW_COUNT;

            IF SQLCODE > 0 THEN
                OUT_RDM_ID := IN_RDM_ID_UUID;
                RESP_CD := 'E35190003';
                RESP_MSG := 'REDEMPTION TRAN INSERTED SUCCESSFULLY';
                SQLCODE_PARM := '0';
            ELSE
                RESP_CD := 'E35190903';
                RESP_MSG := 'THE SYSTEM CANNOT PROCESS YOUR REQUEST. PLEASE TRY AFTER SOME TIME.';
                SQLCODE_PARM := '100';
            END IF;
            RETURN;
        EXCEPTION
            WHEN OTHERS THEN
                SQLCODE_PARM := SQLSTATE;
                RESP_CD := 'E35190903';
                RESP_MSG := 'THE SYSTEM CANNOT PROCESS YOUR REQUEST. PLEASE TRY AFTER SOME TIME.';
                ERR_MSG := SQLERRM;
                RETURN;
        END;
    end if; 

    BEGIN
        IF IN_ACT_IN = 'Y' THEN
            RESP_CD := 'E35190002';
            RESP_MSG := 'PARTICIPANT ALREADY REDEEMED.';
            SQLCODE_PARM := SQLCODE;
            RETURN;
        ELSE
            UPDATE tgabm10.gabm_rdm
                SET ACT_IN = IN_ACT_IN, LST_UPDT_BY_PRCS_NM = IN_UPDT_BY_PRCS_NM, LST_UPDT_TS = CURRENT_TIMESTAMP
                WHERE RDM_CD = IN_RDM_CD AND RDM_TYPE_ID = RDM_TYPE_ID_TEMP AND PTCP_ID = IN_PTCP_ID;

                GET DIAGNOSTICS SQLCODE = ROW_COUNT;

                IF SQLCODE > 0 THEN
                        SQLCODE_PARM := '0';
                        RESP_CD := 'E35190004';
                        RESP_MSG := 'REDEMPTION TRAN UPDATED SUCCESSFULLY.';
                ELSE
                        SQLCODE_PARM := '100';
                        RESP_CD := 'E35190904';
                        RESP_MSG := 'THE SYSTEM CANNOT PROCESS YOUR REQUEST. PLEASE TRY AFTER SOME TIME.';
                END IF;
                RETURN;
        END IF;
    EXCEPTION
        WHEN OTHERS THEN
            RESP_MSG := 'THE SYSTEM CANNOT PROCESS YOUR REQUEST. PLEASE TRY AFTER SOME TIME.';
            SQLCODE_PARM := SQLSTATE;
            ERR_MSG := SQLERRM;
            RETURN;
    END;
EXCEPTION
    WHEN OTHERS THEN
        SQLCODE_PARM := SQLCODE;
        RESP_CD := 'E35190999';
        RESP_MSG := 'SQL EXCEPTION.CHECK SQLCODE TO FIX.';
        ERR_MSG := SQLERRM;
        RETURN;
END;
$$ LANGUAGE plpgsql;
GRANT EXECUTE ON FUNCTION tgabm10.e3rp5190 TO gabmusr;