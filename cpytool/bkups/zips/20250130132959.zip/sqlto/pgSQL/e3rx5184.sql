CREATE OR REPLACE FUNCTION tgabm10.e3rx5184(
    IN_RWRD_GRP_NM CHAR(64),
    IN_CMPGN_ID CHAR(36),
    OUT OUT_RDM_COUNT INTEGER,
    OUT SQLCODE_PARM CHAR(10),
    OUT RESP_CD CHAR(14),
    OUT RESP_MSG CHAR(100),
    OUT ERR_MSG CHAR(100),
    OUT RESULT_SET_1 REFCURSOR
) RETURNS RECORD AS $$
DECLARE
    SQLCODE CHAR(10);
    REC_EXISTS INTEGER;
    WS_RDM_STA_ID SMALLINT;
    WS_STRT_TS CHAR(26);
    WS_CMPGN_STRT_DT CHAR(10);
    WS_STRT_DFTL CHAR(16) DEFAULT '-00.00.00.000000';
    IN_CMPGN_ID_UUID UUID;
BEGIN
    IN_CMPGN_ID_UUID := IN_CMPGN_ID::UUID;
    SQLCODE_PARM := '';
    RESP_CD := '';
    RESP_MSG := '';
    ERR_MSG := '';

    BEGIN
        SELECT TO_CHAR(CMPGN_STRT_DT, 'YYYY-MM-DD')
        INTO WS_CMPGN_STRT_DT
        FROM tgabm10.gabm_cmpgn
        WHERE CMPGN_ID = IN_CMPGN_ID_UUID
        AND CMPGN_END_DT >= CURRENT_DATE
        LIMIT 1;

        IF WS_CMPGN_STRT_DT IS NULL THEN
            SQLCODE := '100';
        ELSE
            SQLCODE := '0';
        END IF;
    EXCEPTION
        WHEN OTHERS THEN
            SQLCODE := SQLSTATE;
            ERR_MSG := SQLERRM;
    END;

    CASE
        WHEN SQLCODE = '0' THEN
            RESP_CD := 'E35184000';
            RESP_MSG := 'CAMPAIGN ID FOUND.';
            SQLCODE_PARM := SQLCODE;
        WHEN SQLCODE = '100' THEN
            RESP_CD := 'E35184100';
            RESP_MSG := 'NO ACTIVE CAMPAIGN FOUND.';
            SQLCODE_PARM := SQLCODE;
            RETURN;
        ELSE
            RESP_CD := 'E35184900';
            RESP_MSG := 'THE SYSTEM CANNOT PROCESS YOUR REQUEST. PLEASE TRY AFTER SOME TIME.';
            SQLCODE_PARM := SQLCODE;
            RETURN;
    END CASE;

    WS_STRT_TS := WS_CMPGN_STRT_DT || WS_STRT_DFTL;

    IF IN_RWRD_GRP_NM = '' THEN
            RESP_CD := 'E35184101';
            RESP_MSG := 'RWRD GRP NM IS BLANK.';
            SQLCODE_PARM := SQLCODE;
            RETURN;
    END IF;

    BEGIN
        SELECT 1
        INTO REC_EXISTS
        FROM tgabm10.gabm_rwrd
        WHERE RWRD_GRP_NM = IN_RWRD_GRP_NM
        AND ACT_IN = 'Y'
        LIMIT 1;

        IF REC_EXISTS IS NULL THEN
            SQLCODE := '100';
        ELSE
            SQLCODE := '0';
        END IF;
    EXCEPTION
        WHEN OTHERS THEN
            SQLCODE := SQLSTATE;
            ERR_MSG := SQLERRM;
    END;

    CASE
        WHEN SQLCODE = '0' THEN
            RESP_CD := 'E35184002';
            RESP_MSG := 'RWRD GRP NM FOUND.';
            SQLCODE_PARM := SQLCODE;
        WHEN SQLCODE = '100' THEN
            RESP_CD := 'E35184102';
            RESP_MSG := 'RWRD GRP NM NOT FOUND.';
            SQLCODE_PARM := SQLCODE;
            RETURN;
        ELSE
            RESP_CD := 'E35184902';
            RESP_MSG := 'THE SYSTEM CANNOT PROCESS YOUR REQUEST. PLEASE TRY AFTER SOME TIME.';
            SQLCODE_PARM := SQLCODE;
            RETURN;
    END CASE;

    BEGIN
        SELECT RDM_STA_ID
        INTO WS_RDM_STA_ID
        FROM tgabm10.gabm_rdm_sta
        WHERE RDM_STA_CD = 'REDEEMED'
        AND ACT_IN = 'Y'
        LIMIT 1;

        IF WS_RDM_STA_ID IS NULL THEN
            SQLCODE := '100';
        ELSE
            SQLCODE := '0';
        END IF;
    EXCEPTION
        WHEN OTHERS THEN
            SQLCODE := SQLSTATE;
            ERR_MSG := SQLERRM;
    END;

    CASE
        WHEN SQLCODE = '0' THEN
            RESP_CD := 'E35184003';
            RESP_MSG := 'RDM STAID FOUND.';
            SQLCODE_PARM := SQLCODE;
        WHEN SQLCODE = '100' THEN
            RESP_CD := 'E35184103';
            RESP_MSG := 'RDM STAID NOT FOUND.';
            SQLCODE_PARM := SQLCODE;
            RETURN;
        ELSE
            RESP_CD := 'E35184903';
            RESP_MSG := 'THE SYSTEM CANNOT PROCESS YOUR REQUEST. PLEASE TRY AFTER SOME TIME.';
            SQLCODE_PARM := SQLCODE;
            RETURN;
    END CASE;

    BEGIN
        SELECT COUNT(*)
        INTO OUT_RDM_COUNT
        FROM tgabm10.gabm_cmpgn_rdm_trans CRT
        JOIN tgabm10.gabm_ptcp PT ON CRT.PTCP_ID = PT.PTCP_ID
        JOIN tgabm10.gabm_rwrd R ON PT.RWRD_ID = R.RWRD_ID
        JOIN tgabm10.gabm_cmpgn_rwrd CR ON CRT.CMPGN_ID = CR.CMPGN_ID
        WHERE CRT.CMPGN_ID = IN_CMPGN_ID_UUID
        AND CRT.ACT_IN = 'Y'
        AND CRT.RDM_STA_ID = WS_RDM_STA_ID
        AND CRT.CREAT_TS BETWEEN WS_STRT_TS AND CURRENT_TIMESTAMP
        AND R.RWRD_GRP_NM = IN_RWRD_GRP_NM
        AND PT.ACT_IN = 'Y';

        IF OUT_RDM_COUNT = 0 THEN
            SQLCODE := '100';
        ELSE
            SQLCODE := '0';
        END IF;
    EXCEPTION
        WHEN OTHERS THEN
            SQLCODE := SQLSTATE;
            ERR_MSG := SQLERRM;
    END;

    CASE
        WHEN SQLCODE = '0' THEN
            RESP_CD := 'E35184005';
            RESP_MSG := 'RDM COUNT FETCH SUCESSFULLY.';
            SQLCODE_PARM := SQLCODE;
        ELSE
            RESP_CD := 'E35184905';
            RESP_MSG := 'THE SYSTEM CANNOT PROCESS YOUR REQUEST. PLEASE TRY AFTER SOME TIME.';
            SQLCODE_PARM := SQLCODE;
            RETURN;
    END CASE;

    OPEN RESULT_SET_1 FOR
    SELECT NULL;    
    -- SELECT * FROM tgabm10.gabm_cmpgn_rdm_trans
    -- WHERE CMPGN_ID = IN_CMPGN_ID_UUID;

    RETURN;
EXCEPTION
    WHEN OTHERS THEN
        SQLCODE_PARM := SQLSTATE;
        RESP_CD := 'E35184999';
        RESP_MSG := 'SQL EXCEPTION.CHECK SQLCODE TO FIX.';
        ERR_MSG := SQLERRM;
        RETURN;
END;
$$ LANGUAGE plpgsql;
GRANT EXECUTE ON FUNCTION tgabm10.e3rx5184 TO gabmusr;