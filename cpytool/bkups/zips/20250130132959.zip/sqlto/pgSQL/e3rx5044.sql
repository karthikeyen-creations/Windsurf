CREATE OR REPLACE FUNCTION tgabm10.e3rx5044(
	IN_CMPGN_ID CHAR(36),
	OUT SQLCODE_PARM CHAR(10),
	OUT RESP_CD CHAR(14),
	OUT RESP_MSG CHAR(100),
	OUT ERR_MSG CHAR(100),
	OUT RESULT_SET_1 REFCURSOR
)
RETURNS RECORD AS $$
DECLARE
	SQLCODE CHAR(10);
	REC_EXISTS INTEGER;
	IN_CMPGN_ID_UUID UUID;
	rec RECORD;
BEGIN
	IN_CMPGN_ID_UUID := IN_CMPGN_ID::UUID;

    SQLCODE_PARM := '';
    RESP_CD := '';
    RESP_MSG := '';
    ERR_MSG := '';

	BEGIN
		SELECT 1 INTO REC_EXISTS
		FROM tgabm10.gabm_cmpgn
		WHERE cmpgn_id = IN_CMPGN_ID_UUID
		AND cmpgn_end_dt >= CURRENT_DATE
		LIMIT 1;

		IF REC_EXISTS IS NULL THEN
			SQLCODE := '100';
		ELSE
			SQLCODE := '0';
		END IF;

		CASE
			WHEN SQLCODE = '0' THEN
				RESP_CD := 'E35044000';
				RESP_MSG := 'CAMPAIGN ID FOUND.';
				SQLCODE_PARM := SQLCODE;
			ELSE
				RESP_CD := 'E35044100';
				RESP_MSG := 'NO ACTIVE CAMPAIGN FOUND.';
				SQLCODE_PARM := SQLCODE;
				RETURN;
		END CASE;
	EXCEPTION
		WHEN OTHERS THEN
			SQLCODE := SQLSTATE;
			RESP_CD := 'E35044900';
            RESP_MSG := 'THE SYSTEM CANNOT PROCESS YOUR REQUEST. PLEASE TRY AFTER SOME TIME.';
            SQLCODE_PARM := SQLCODE;
			ERR_MSG := SQLERRM;
			RETURN;
	END;

	BEGIN
		OPEN RESULT_SET_1 FOR
		SELECT c.cmpgn_id, c.rwrd_id, r.rwrd_nm, r.rwrd_ds, r.rdm_lmt_ct, r.act_in,
			   r.creat_by_prcs_nm, r.creat_ts, r.lst_updt_by_prcs_nm, r.lst_updt_ts,
			   r.rwrd_class_cd, r.rwrd_cmnt_tx, r.rwrd_dtl_ds, r.rwrd_ntfy_tx,
			   r.rwrd_grp_nm, r.rwrd_disp_seq_no
		FROM tgabm10.gabm_cmpgn_rwrd c
		JOIN tgabm10.gabm_rwrd r ON c.rwrd_id = r.rwrd_id
		WHERE c.cmpgn_id = IN_CMPGN_ID_UUID
		AND c.act_in = 'Y'
		AND r.act_in = 'Y'
		ORDER BY r.rwrd_disp_seq_no;

		FETCH RESULT_SET_1 INTO rec;
		IF NOT FOUND THEN
			SQLCODE := '100';
		ELSE
			SQLCODE := '0';
		END IF;

		CASE
			WHEN SQLCODE = '0' THEN
				RESP_CD := 'E35044001';
				RESP_MSG := 'CMPGN RWRD DATA FETCHED SUCCESSFULLY';
				SQLCODE_PARM := SQLCODE;
				RETURN;
			ELSE
				RESP_CD := 'E35044901';
				RESP_MSG := 'THE SYSTEM CANNOT PROCESS YOUR REQUEST. PLEASE TRY AFTER SOME TIME.';
				SQLCODE_PARM := SQLCODE;
				RETURN;
		END CASE;
	EXCEPTION
		WHEN OTHERS THEN
			SQLCODE := SQLSTATE;
			RESP_CD := 'E35044901';
            RESP_MSG := 'THE SYSTEM CANNOT PROCESS YOUR REQUEST. PLEASE TRY AFTER SOME TIME.';
            SQLCODE_PARM := SQLCODE;
			ERR_MSG := SQLERRM;
			RETURN;
	END;
EXCEPTION
    WHEN OTHERS THEN
        SQLCODE := SQLSTATE;
        SQLCODE_PARM := SQLCODE;
        RESP_CD := 'E35044999';
        RESP_MSG := 'SQL EXCEPTION. CHECK SQLCODE TO FIX.';
        ERR_MSG := SQLERRM;
        RETURN;
END;
$$ LANGUAGE plpgsql;
GRANT EXECUTE ON FUNCTION tgabm10.e3rx5044 TO gabmusr;