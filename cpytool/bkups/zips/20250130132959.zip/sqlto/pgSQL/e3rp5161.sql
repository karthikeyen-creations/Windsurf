CREATE OR REPLACE FUNCTION tgabm10.e3rp5161(
    IN_RWRD_ID CHAR(2100),
    IN_TRGT_CARD_ACCT_ID CHAR(64),
    OUT OUT_PREV_RDM_CNT INTEGER,
    OUT SQLCODE_PARM CHAR(10),
    OUT RESP_CD CHAR(14),
    OUT RESP_MSG CHAR(100),
    OUT ERR_MSG CHAR(100),
    OUT RESULT_SET_1 REFCURSOR
) RETURNS RECORD AS $$
DECLARE
    SQLCODE CHAR(10);
    V_POSITION INTEGER DEFAULT 1;
    V_POSITION_MAX INTEGER DEFAULT 2100;
    rec RECORD;
BEGIN
    SQLCODE_PARM := '';  
    RESP_CD := '';
    RESP_MSG := '';
	ERR_MSG := '';

    -- PRE-VALIDATE INPUT ARRAY
    IF (IN_RWRD_ID = '' OR IN_RWRD_ID IS NULL) THEN
        RESP_CD := 'E35161101';
        RESP_MSG := 'RWRD ARRAY IS EMPTY.';
        SQLCODE_PARM := '0';
        OUT_PREV_RDM_CNT := 0;
        RETURN;
    END IF;

    -- PROCESS ARRAY AND LOAD INTO THE TEMP TABLE
    BEGIN
        DROP TABLE IF EXISTS t15161_tmp1;
		COMMIT;
        CREATE TEMP TABLE t15161_tmp1 (
            RWRD_ID CHAR(25)
        ) ON COMMIT PRESERVE ROWS;
    EXCEPTION
        WHEN OTHERS THEN
            SQLCODE_PARM := SQLSTATE;
            RESP_CD := 'E35161991';
            RESP_MSG := 'TEMP TABLE ALREADY EXISTS';
            ERR_MSG := SQLERRM;
    END;

    WHILE SUBSTR(IN_RWRD_ID, V_POSITION, 25) <> ' ' OR V_POSITION > V_POSITION_MAX LOOP
		INSERT INTO t15161_tmp1 (RWRD_ID)
		VALUES (SUBSTR(IN_RWRD_ID, V_POSITION, 25));
		GET DIAGNOSTICS SQLCODE = ROW_COUNT;
        V_POSITION := V_POSITION + 25;
    END LOOP;

    BEGIN
        SELECT COUNT(*)
        INTO OUT_PREV_RDM_CNT
        FROM tgabm10.gabm_cmpgn_enroll_req E
        JOIN tgabm10.gabm_trgt_card_acct_dtl T ON E.trgt_card_acct_id = T.trgt_card_acct_id
        JOIN tgabm10.gabm_ptcp P ON E.ptcp_id = P.ptcp_id
        JOIN t15161_tmp1 R ON P.rwrd_id = R.rwrd_id
        WHERE E.cmpgn_enroll_sta_tx = 'REDEEMED'
        AND T.trgt_card_acct_id = IN_TRGT_CARD_ACCT_ID;
        IF OUT_PREV_RDM_CNT IS NULL THEN
            SQLCODE := '100';
        ELSE
            SQLCODE := '0';
        END IF;
    EXCEPTION
        WHEN OTHERS THEN
			SQLCODE := SQLSTATE;
            ERR_MSG := SQLERRM;
    END;

    CASE
        WHEN SQLCODE = '0' THEN
            RESP_CD := 'E35161002';
            RESP_MSG := 'PRE EVENT CUMULATIVE RDM CNT FETCH.';
            SQLCODE_PARM := SQLCODE;
        ELSE
            RESP_CD := 'E35161902';
            RESP_MSG := 'THE SYSTEM CANNOT PROCESS YOUR REQUEST. PLEASE TRY AFTER SOME TIME.';
            SQLCODE_PARM := SQLCODE;
            RETURN;
    END CASE;
	BEGIN
		OPEN RESULT_SET_1 FOR
			SELECT P.rwrd_id, COUNT(*) AS rdm_count
			FROM tgabm10.gabm_cmpgn_enroll_req E
			JOIN tgabm10.gabm_trgt_card_acct_dtl T ON E.trgt_card_acct_id = T.trgt_card_acct_id
			JOIN tgabm10.gabm_ptcp P ON E.ptcp_id = P.ptcp_id
			JOIN t15161_tmp1 R ON P.rwrd_id = R.rwrd_id
			WHERE E.cmpgn_enroll_sta_tx = 'REDEEMED'
			AND T.trgt_card_acct_id = IN_TRGT_CARD_ACCT_ID
			GROUP BY P.rwrd_id;

		FETCH RESULT_SET_1 INTO rec;
		IF NOT FOUND THEN
			SQLCODE := '100';
		ELSE
			SQLCODE := '0';
		END IF;
	EXCEPTION
		WHEN OTHERS THEN
			SQLCODE := SQLSTATE;
			ERR_MSG := SQLERRM;
	END;

	CASE
		WHEN SQLCODE = '0' THEN
			RESP_CD := 'E35161003';
			RESP_MSG := 'PRE EVENT RDM CNT FETCH.';
			SQLCODE_PARM := SQLCODE;
			RETURN;
		ELSE
			RESP_CD := 'E35161903';
			RESP_MSG := 'THE SYSTEM CANNOT PROCESS YOUR REQUEST. PLEASE TRY AFTER SOME TIME.';
			SQLCODE_PARM := SQLCODE;
			RETURN;
	END CASE;
EXCEPTION
	WHEN OTHERS THEN
		SQLCODE_PARM := SQLSTATE;
		RESP_CD := 'E35161999';
		RESP_MSG := 'SQL EXCEPTION. CHECK SQLCODE TO FIX.';
		ERR_MSG := SQLERRM;
		RETURN;
END;
$$ LANGUAGE plpgsql;
GRANT EXECUTE ON FUNCTION tgabm10.e3rp5161 TO gabmusr;