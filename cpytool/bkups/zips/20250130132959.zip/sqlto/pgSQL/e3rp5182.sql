CREATE OR REPLACE FUNCTION tgabm10.e3rp5182(
    IN_CMPGN_ID CHAR(36),
    IN_PTCP_ID CHAR(64),
    IN_RWRD_ID CHAR(36),
    IN_RDM_LMT SMALLINT,
    OUT RDM_ALLOWED CHAR(1),
    OUT SQLCODE_PARM CHAR(10),
    OUT RESP_CD CHAR(14),
    OUT RESP_MSG CHAR(100),
    OUT ERR_MSG CHAR(100)
) RETURNS RECORD AS $$
DECLARE
    IN_CMPGN_ID_UUID UUID;
    IN_RWRD_ID_UUID UUID;
    SQLCODE CHAR(10);
    REC_EXISTS INTEGER;
    PTCP_LMT_CT SMALLINT;
    WS_STRT_DFTL CHAR(16) DEFAULT '-00.00.00.000000';
    WS_END_DFTL CHAR(16) DEFAULT '-23.59.59.999999';
    WS_STRT_TS TIMESTAMP;
    WS_END_TS TIMESTAMP;
    WS_CURR_DATE CHAR(10);
    WS_RDM_STA_ID SMALLINT;
BEGIN
    IN_CMPGN_ID_UUID := IN_CMPGN_ID::UUID;
    IN_RWRD_ID_UUID := IN_RWRD_ID::UUID;

    SQLCODE_PARM := '';
    RESP_CD := '';
    RESP_MSG := '';
    ERR_MSG := '';

    -- SET TIME STAMP
    SELECT TO_CHAR(CURRENT_DATE, 'YYYY-MM-DD') INTO WS_CURR_DATE;

    WS_STRT_TS := WS_CURR_DATE || WS_STRT_DFTL;
    WS_END_TS := WS_CURR_DATE || WS_END_DFTL;

    -- VERIFY IF CAMPAIGN EXIST AND IS ACTIVE.
    BEGIN
        SELECT 1 INTO REC_EXISTS
        FROM tgabm10.gabm_cmpgn
        WHERE cmpgn_id = IN_CMPGN_ID_UUID
        AND cmpgn_end_dt >= CURRENT_DATE
        LIMIT 1;

        IF REC_EXISTS IS NULL THEN
            SQLCODE := '100';
        ELSE
            SQLCODE := '0';
        END IF;
    EXCEPTION
        WHEN OTHERS THEN
            SQLCODE := SQLSTATE;
            ERR_MSG := SQLERRM;
    END;

    IF SQLCODE = '0' THEN
        RESP_CD := 'E35182000';
        RESP_MSG := 'CAMPAIGN ID FOUND.';
        SQLCODE_PARM := SQLCODE;
    ELSIF SQLCODE = '100' THEN
        RESP_CD := 'E35182100';
        RESP_MSG := 'NO ACTIVE CAMPAIGN FOUND.';
        SQLCODE_PARM := SQLCODE;
        RETURN;
    ELSE
        RESP_CD := 'E35182900';
        RESP_MSG := 'THE SYSTEM CANNOT PROCESS YOUR REQUEST. PLEASE TRY AFTER SOME TIME.';
        SQLCODE_PARM := SQLCODE;
        RETURN;
    END IF;

    -- VERIFY IF REWARD EXISTS AND IS ACTIVE.
    BEGIN
        SELECT 1 INTO REC_EXISTS
        FROM tgabm10.gabm_rwrd
        WHERE rwrd_id = IN_RWRD_ID_UUID
        AND act_in = 'Y'
        LIMIT 1;

        IF REC_EXISTS IS NULL THEN
            SQLCODE := '100';
        ELSE
            SQLCODE := '0';
        END IF;
    EXCEPTION
        WHEN OTHERS THEN
            SQLCODE := SQLSTATE;
            ERR_MSG := SQLERRM;
    END;

    IF SQLCODE = '0' THEN
        RESP_CD := 'E35182001';
        RESP_MSG := 'RWRD ID FOUND.';
        SQLCODE_PARM := SQLCODE;
    ELSIF SQLCODE = '100' THEN
        RESP_CD := 'E35182101';
        RESP_MSG := 'RWRD ID NOT FOUND.';
        SQLCODE_PARM := SQLCODE;
        RETURN;
    ELSE
        RESP_CD := 'E35182901';
        RESP_MSG := 'THE SYSTEM CANNOT PROCESS YOUR REQUEST. PLEASE TRY AFTER SOME TIME.';
        SQLCODE_PARM := SQLCODE;
        RETURN;
    END IF;

    -- VERIFY IF REDEMPTION CODE EXISTS
    BEGIN
        SELECT rdm_sta_id INTO WS_RDM_STA_ID
        FROM tgabm10.gabm_rdm_sta
        WHERE rdm_sta_cd = 'REDEEMED'
        AND act_in = 'Y'
        LIMIT 1;

        IF WS_RDM_STA_ID IS NULL THEN
            SQLCODE := '100';
        ELSE
            SQLCODE := '0';
        END IF;
    EXCEPTION
        WHEN OTHERS THEN
            SQLCODE := SQLSTATE;
            ERR_MSG := SQLERRM;
    END;

    IF SQLCODE = '0' THEN
        RESP_CD := 'E35182003';
        RESP_MSG := 'RDM STA ID FOUND.';
        SQLCODE_PARM := SQLCODE;
    ELSIF SQLCODE = '100' THEN
        RESP_CD := 'E35182103';
        RESP_MSG := 'RDM STA ID NOT FOUND.';
        SQLCODE_PARM := SQLCODE;
        RETURN;
    ELSE
        RESP_CD := 'E35182903';
        RESP_MSG := 'THE SYSTEM CANNOT PROCESS YOUR REQUEST. PLEASE TRY AFTER SOME TIME.';
        SQLCODE_PARM := SQLCODE;
        RETURN;
    END IF;

    -- IDENTIFY THE PRIOR # OF REDEMPTIONS FOR THE PARTICIPANT AND CAMPAIGN ID
    BEGIN
        SELECT COUNT(*) INTO PTCP_LMT_CT
        FROM tgabm10.gabm_cmpgn_rdm_trans crt
        JOIN tgabm10.gabm_ptcp p ON crt.ptcp_id = p.ptcp_id
        WHERE crt.cmpgn_id = IN_CMPGN_ID_UUID
        AND crt.ptcp_id = IN_PTCP_ID
        AND crt.creat_ts >= WS_STRT_TS
        AND crt.creat_ts <= WS_END_TS
        AND crt.rdm_staid = WS_RDM_STA_ID
        AND p.rwrd_id = IN_RWRD_ID_UUID
        AND p.act_in = 'Y';

        IF PTCP_LMT_CT IS NULL THEN
            SQLCODE := '100';
        ELSE
            SQLCODE := '0';
        END IF;
    EXCEPTION
        WHEN OTHERS THEN
            SQLCODE := SQLSTATE;
            ERR_MSG := SQLERRM;
    END;

    IF SQLCODE = '0' THEN
        RESP_CD := 'E35182002';
        RESP_MSG := 'RDM LIMIT VERIFIED.';
        SQLCODE_PARM := SQLCODE;
    ELSE
        RESP_CD := 'E35182902';
        RESP_MSG := 'THE SYSTEM CANNOT PROCESS YOUR REQUEST. PLEASE TRY AFTER SOME TIME.';
        SQLCODE_PARM := SQLCODE;
        RETURN;
    END IF;

    IF PTCP_LMT_CT < IN_RDM_LMT THEN
        RDM_ALLOWED := 'Y';
    ELSE
        RDM_ALLOWED := 'N';
    END IF;

    RETURN;
EXCEPTION
    WHEN OTHERS THEN
        SQLCODE := SQLSTATE;
        ERR_MSG := SQLERRM;
        SQLCODE_PARM := SQLCODE;
        RESP_CD := 'E35182999';
        RESP_MSG := 'SQL EXCEPTION.CHECK SQLCODE TO FIX.';
        RETURN;
END;
$$ LANGUAGE plpgsql;

GRANT EXECUTE ON FUNCTION tgabm10.e3rp5182 TO gabmusr;