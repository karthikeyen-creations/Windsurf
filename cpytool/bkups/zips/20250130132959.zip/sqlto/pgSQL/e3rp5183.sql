CREATE OR REPLACE FUNCTION tgabm10.e3rp5183(
    IN_CMPGN_ID CHAR(36),
    IN_RDM_LMT SMALLINT,
    IN_DAILY_RDM_LMT_STR_DT CHAR(10),
    IN_DAILY_RDM_LMT_END_DT CHAR(10),
    IN_PARM_NM CHAR(64),
    IN_PARM_VAL_TX VARCHAR(4096),
    IN_RDM_CD CHAR(64),
    IN_RDM_TYPE_CD CHAR(50),
    OUT RDM_ALLOWED CHAR(1),
    OUT SQLCODE_PARM CHAR(10),
    OUT RESP_CD CHAR(14),
    OUT RESP_MSG CHAR(100),
    OUT ERR_MSG CHAR(100)
) RETURNS RECORD AS $$
DECLARE
    SQLCODE CHAR(10);
    REC_EXISTS INTEGER;
    PTCP_LMT_CT SMALLINT;
    WS_STRT_DFTL CHAR(16) DEFAULT '-00.00.00.000000';
    WS_END_DFTL CHAR(16) DEFAULT '-24.00.00.000000';
    WS_STRT_TS TIMESTAMP;
    WS_END_TS TIMESTAMP;
    WS_CMPGN_STRT_DT CHAR(10);
    WS_CMPGN_END_DT CHAR(10);
    WS_RDM_STA_ID SMALLINT;
    IN_CMPGN_ID_UUID UUID;
BEGIN
    IN_CMPGN_ID_UUID := IN_CMPGN_ID::UUID;

    SQLCODE_PARM := '';
    RESP_CD := '';
    RESP_MSG := '';
    ERR_MSG := '';

    BEGIN
        SELECT TO_CHAR(CMPGN_STRT_DT, 'YYYY-MM-DD'), TO_CHAR(CMPGN_END_DT, 'YYYY-MM-DD')
        INTO WS_CMPGN_STRT_DT, WS_CMPGN_END_DT
        FROM tgabm10.GABM_CMPGN
        WHERE CMPGN_ID = IN_CMPGN_ID_UUID
        AND CMPGN_END_DT >= CURRENT_DATE
        LIMIT 1;

        IF WS_CMPGN_STRT_DT IS NULL THEN
            SQLCODE := '100';
        ELSE
            SQLCODE := '0';
        END IF;

        EXCEPTION WHEN OTHERS THEN
            SQLCODE := SQLSTATE;
            ERR_MSG := SQLERRM;
    END;

    CASE 
        WHEN SQLCODE = '0' THEN
            RESP_CD := 'E35183000';
            RESP_MSG := 'CAMPAIGN ID FOUND.';
            SQLCODE_PARM := SQLCODE;
        WHEN SQLCODE = '100' THEN
            RESP_CD := 'E35183100';
            RESP_MSG := 'NO ACTIVE CAMPAIGN FOUND.';
            SQLCODE_PARM := SQLCODE;
            RETURN;
        ELSE
            RESP_CD := 'E35183900';
            RESP_MSG := 'THE SYSTEM CANNOT PROCESS YOUR REQUEST. PLEASE TRY AFTER SOME TIME.';
            SQLCODE_PARM := SQLCODE;
            RETURN;
    END CASE;

    IF IN_DAILY_RDM_LMT_STR_DT <> '' THEN
        WS_STRT_TS := IN_DAILY_RDM_LMT_STR_DT || WS_STRT_DFTL;
        WS_END_TS := IN_DAILY_RDM_LMT_END_DT || WS_END_DFTL;
    ELSE
        WS_STRT_TS := WS_CMPGN_STRT_DT || WS_STRT_DFTL;
        WS_END_TS := WS_CMPGN_END_DT || WS_END_DFTL;
    END IF;

    BEGIN
        SELECT 1
        INTO REC_EXISTS
        FROM tgabm10.GABM_RDM_TYPE
        WHERE RDM_TYPE_CD = IN_RDM_TYPE_CD
        AND ACT_IN = 'Y'
        LIMIT 1;

        IF REC_EXISTS IS NULL THEN
            SQLCODE := '100';
        ELSE
            SQLCODE := '0';
        END IF;

        EXCEPTION WHEN OTHERS THEN
            SQLCODE := SQLSTATE;
            ERR_MSG := SQLERRM;
    END;

    CASE
        WHEN SQLCODE = '0' THEN
            RESP_CD := 'E35183001';
            RESP_MSG := 'RDM TYPE CD FOUND.';
            SQLCODE_PARM := SQLCODE;
        WHEN SQLCODE = '100' THEN
            RESP_CD := 'E35183101';
            RESP_MSG := 'RDM TYPE CD NOT FOUND.';
            SQLCODE_PARM := SQLCODE;
            RETURN;
        ELSE
            RESP_CD := 'E35183901';
            RESP_MSG := 'THE SYSTEM CANNOT PROCESS YOUR REQUEST. PLEASE TRY AFTER SOME TIME.';
            SQLCODE_PARM := SQLCODE;
            RETURN;
    END CASE;

    BEGIN
        SELECT RDM_STA_ID
        INTO WS_RDM_STA_ID
        FROM tgabm10.GABM_RDM_STA
        WHERE RDM_STA_CD = 'REDEEMED'
        AND ACT_IN = 'Y'
        LIMIT 1;

        IF WS_RDM_STA_ID IS NULL THEN
            SQLCODE := '100';
        ELSE
            SQLCODE := '0';
        END IF;

        EXCEPTION WHEN OTHERS THEN
            SQLCODE := SQLSTATE;
            ERR_MSG := SQLERRM;
    END;

    CASE
        WHEN SQLCODE = '0' THEN
            RESP_CD := 'E35183003';
            RESP_MSG := 'RDM STA ID FOUND.';
            SQLCODE_PARM := SQLCODE;
        WHEN SQLCODE = '100' THEN
            RESP_CD := 'E35183103';
            RESP_MSG := 'RDM STA ID NOT FOUND.';
            SQLCODE_PARM := SQLCODE;
            RETURN;
        ELSE
            RESP_CD := 'E35183903';
            RESP_MSG := 'THE SYSTEM CANNOT PROCESS YOUR REQUEST. PLEASE TRY AFTER SOME TIME.';
            SQLCODE_PARM := SQLCODE;
            RETURN;
    END CASE;

    BEGIN
        SELECT COUNT(*)
        INTO PTCP_LMT_CT
        FROM tgabm10.GABM_CMPGN_RDM_TRANS CRT
        JOIN tgabm10.GABM_PTCP P ON CRT.PTCP_ID = P.PTCP_ID
        JOIN tgabm10.GABM_RDM RDM ON P.PTCP_ID = RDM.PTCP_ID
        JOIN tgabm10.GABM_RDM_TYPE RT ON RDM.RDM_TYPE_ID = RT.RDM_TYPE_ID
        JOIN tgabm10.GABM_CMPGN_RWRD CR ON CRT.CMPGN_ID = CR.CMPGN_ID
        JOIN tgabm10.GABM_APPL_CMPNT_RWRD_PARM ACRP ON P.RWRD_ID = ACRP.RWRD_ID
        WHERE CRT.CMPGN_ID = IN_CMPGN_ID_UUID
        AND RDM.RDM_CD = IN_RDM_CD
        AND RT.RDM_TYPE_CD = IN_RDM_TYPE_CD
        AND CRT.CREAT_TS BETWEEN WS_STRT_TS AND WS_END_TS
        AND CRT.RDM_STA_ID = WS_RDM_STA_ID
        AND P.ACT_IN = 'Y'
        AND CR.ACT_IN = 'Y'
        AND ACRP.PARM_NM = IN_PARM_NM
        AND ACRP.PARM_VAL_TX = IN_PARM_VAL_TX
        AND ACRP.ACT_IN = 'Y'
        AND RDM.ACT_IN = 'Y'
        AND RT.ACT_IN = 'Y';

        IF PTCP_LMT_CT IS NULL THEN
            SQLCODE := '100';
        ELSE
            SQLCODE := '0';
        END IF;

        EXCEPTION WHEN OTHERS THEN
            SQLCODE := SQLSTATE;
            ERR_MSG := SQLERRM;
    END;

    CASE 
        WHEN SQLCODE = '0' THEN
            RESP_CD := 'E35183002';
            RESP_MSG := 'RDM LIMIT VERIFIED.';
            SQLCODE_PARM := SQLCODE;
        ELSE
            RESP_CD := 'E35183902';
            RESP_MSG := 'THE SYSTEM CANNOT PROCESS YOUR REQUEST. PLEASE TRY AFTER SOME TIME.';
            SQLCODE_PARM := SQLCODE;
            RETURN;
    END CASE;

    IF PTCP_LMT_CT < IN_RDM_LMT THEN
        RDM_ALLOWED := 'Y';
    ELSE
        RDM_ALLOWED := 'N';
    END IF;

    RETURN;
EXCEPTION
    WHEN OTHERS THEN
        SQLCODE := SQLSTATE;
        ERR_MSG := SQLERRM; 
        SQLCODE_PARM := SQLCODE;
        RESP_CD := 'E35183999';
        RESP_MSG := 'SQL EXCEPTION.CHECK SQLCODE TO FIX.';
        RETURN;
END;
$$ LANGUAGE plpgsql;
GRANT EXECUTE ON FUNCTION tgabm10.e3rp5183 TO gabmusr;