CREATE OR REPLACE FUNCTION tgabm10.e3rp5176(
    IN_PTCP_ID CHAR(64),
    IN_RWRD_ID CHAR(36),
    IN_ACT_IN CHAR(1),
    IN_CREAT_BY_PRCS_NM CHAR(255),
    IN_LST_UPDT_BY_PRCS_NM CHAR(255),
    IN_RDM_TYPE_CD CHAR(50),
    IN_RDM_CD CHAR(64),
    OUT OUT_PTCP_ID CHAR(64),
    OUT SQLCODE_PARM CHAR(10),
    OUT RESP_CD CHAR(14),
    OUT RESP_MSG CHAR(100),
    OUT ERR_MSG CHAR(100)
) RETURNS RECORD AS $$
DECLARE
    SQLCODE INTEGER;
    REC_EXISTS INTEGER;
    HV_RDM_TYPE_ID SMALLINT;
    IN_RWRD_ID_UUID UUID;
BEGIN
    IN_RWRD_ID_UUID := IN_RWRD_ID::UUID;

    -- Initialize output variables
    SQLCODE_PARM := '';
    RESP_CD := '';
    RESP_MSG := '';
    ERR_MSG := '';

    -- Verify if RDM_TYPE_CD is active
    BEGIN
        SELECT RDM_TYPE_ID INTO HV_RDM_TYPE_ID
        FROM tgabm10.gabm_rdm_type
        WHERE RDM_TYPE_CD = IN_RDM_TYPE_CD AND ACT_IN = 'Y';

        IF HV_RDM_TYPE_ID IS NULL THEN
            RESP_CD := 'E35176101';
            RESP_MSG := 'RDM TYPE CD NOT FOUND.';
            SQLCODE_PARM := '100';
            RETURN;
        ELSE
            RESP_CD := 'E35176001';
            RESP_MSG := 'RDM TYPE CD FOUND.';
            SQLCODE_PARM := '0';
        END IF;
    EXCEPTION
        WHEN OTHERS THEN
            SQLCODE_PARM := SQLSTATE;
            RESP_CD := 'E35176901';
            RESP_MSG := 'THE SYSTEM CANNOT PROCESS YOUR REQUEST. PLEASE TRY AFTER SOME TIME.';
            ERR_MSG := SQLERRM;
            RETURN;
    END;

    -- Verify if RWRD_ID is active
    BEGIN
        SELECT 1 INTO REC_EXISTS
        FROM tgabm10.gabm_rwrd
        WHERE RWRD_ID = IN_RWRD_ID_UUID AND ACT_IN = 'Y'
        LIMIT 1;

        IF REC_EXISTS IS NULL THEN
            RESP_CD := 'E35176102';
            RESP_MSG := 'RWRD ID NOT FOUND.';
            SQLCODE_PARM := '100';
            RETURN;
        ELSE
            RESP_CD := 'E35176002';
            RESP_MSG := 'RWRD ID FOUND.';
            SQLCODE_PARM := '0';
        END IF;
    EXCEPTION
        WHEN OTHERS THEN
            SQLCODE_PARM := SQLSTATE;
            RESP_CD := 'E35176902';
            RESP_MSG := 'THE SYSTEM CANNOT PROCESS YOUR REQUEST. PLEASE TRY AFTER SOME TIME.';
            ERR_MSG := SQLERRM;
            RETURN;
    END;

    -- Verify if PTCP_ID is present
    BEGIN
        SELECT PTCP_ID INTO OUT_PTCP_ID
        FROM tgabm10.gabm_ptcp
        WHERE RWRD_ID = IN_RWRD_ID_UUID
        AND PTCP_ID IN (
            SELECT PTCP_ID FROM tgabm10.gabm_rdm
            WHERE RDM_CD = IN_RDM_CD AND RDM_TYPE_ID = HV_RDM_TYPE_ID
        );

        IF OUT_PTCP_ID IS NULL THEN
            RESP_CD := 'E35176103';
            RESP_MSG := 'PTCP ID NOT FOUND.';
            SQLCODE_PARM := '100';
        ELSE
            RESP_CD := 'E35176003';
            RESP_MSG := 'PTCP ID FOUND, RECORD NOT INSERTED.';
            SQLCODE_PARM := '0';
            RETURN;
        END IF;
    EXCEPTION
        WHEN OTHERS THEN
            SQLCODE_PARM := SQLSTATE;
            RESP_CD := 'E35176903';
            RESP_MSG := 'THE SYSTEM CANNOT PROCESS YOUR REQUEST. PLEASE TRY AFTER SOME TIME.';
            ERR_MSG := SQLERRM;
            RETURN;
    END;

    -- Insert into GABM_PTCP if IN_ACT_IN is 'Y'
    IF IN_ACT_IN = 'Y' THEN
        BEGIN
            INSERT INTO tgabm10.gabm_ptcp (
                PTCP_ID, RWRD_ID, ACT_IN, CREAT_BY_PRCS_NM, CREAT_TS, LST_UPDT_BY_PRCS_NM, LST_UPDT_TS
            ) VALUES (
                IN_PTCP_ID, IN_RWRD_ID_UUID, IN_ACT_IN, IN_CREAT_BY_PRCS_NM, CURRENT_TIMESTAMP, IN_LST_UPDT_BY_PRCS_NM, CURRENT_TIMESTAMP
            );

            RESP_CD := 'E35176004';
            RESP_MSG := 'INSERT SUCCESSFUL IN THE PTCP TABLE.';
            SQLCODE_PARM := '0';
            OUT_PTCP_ID := IN_PTCP_ID;
            RETURN;
        EXCEPTION
            WHEN UNIQUE_VIOLATION THEN
                RESP_CD := 'E35176904';
                RESP_MSG := 'DUPLICATE PTCP ID. INSERT FAILED.';
                SQLCODE_PARM := '-803';
                RETURN;
            WHEN OTHERS THEN
                SQLCODE_PARM := SQLSTATE;
                RESP_CD := 'E35176904';
                RESP_MSG := 'THE SYSTEM CANNOT PROCESS YOUR REQUEST. PLEASE TRY AFTER SOME TIME.';
                ERR_MSG := SQLERRM;
                RETURN;
        END;
    ELSE
        RESP_CD := 'E35176105';
        RESP_MSG := 'ACT_IN IS NOT Y, RECORD NOT INSERTED.';
        SQLCODE_PARM := '0';
        OUT_PTCP_ID := '';
        RETURN;
    END IF;
EXCEPTION
    WHEN OTHERS THEN
        SQLCODE_PARM := SQLSTATE;
        RESP_CD := 'E35176999';
        RESP_MSG := 'SQL EXCEPTION. CHECK SQLCODE TO FIX.';
        ERR_MSG := SQLERRM;
        RETURN;
END;
$$ LANGUAGE plpgsql;
GRANT EXECUTE ON FUNCTION tgabm10.e3rp5176 TO gabmusr;