CREATE OR REPLACE FUNCTION tgabm10.e3rx5031(
    IN_LOG_CREAT_TS TIMESTAMP,
    IN_RDM_CD CHAR(64),
    IN_RDM_TYPE_CD CHAR(50),
    IN_RDM_STA_CD CHAR(50),
    IN_RWRD_ID CHAR(36),
    IN_CMPGN_ID CHAR(36),
    IN_PTCP_ID CHAR(64),
    IN_ACT_IN CHAR(1),
    IN_CREAT_BY_PRCS_NM CHAR(255),
    IN_CREAT_TS TIMESTAMP,
    IN_LST_UPDT_BY_PRCS_NM CHAR(255),
    IN_LST_UPDT_TS TIMESTAMP,
    IN_API_REQ_ID CHAR(100),
    IN_RDM_CARD_TYPE_CD CHAR(100),
    OUT SQLCODE_PARM CHAR(10),
    OUT RESP_CD CHAR(14),
    OUT RESP_MSG CHAR(100),
    OUT ERR_MSG CHAR(100)
) RETURNS RECORD AS $$
DECLARE
    SQLCODE CHAR(10);
    HV_RDM_STA_ID SMALLINT;
    HV_RDM_TYPE_ID SMALLINT;
    IN_RWRD_ID_UUID UUID;
    IN_CMPGN_ID_UUID UUID;
BEGIN
    IN_RWRD_ID_UUID := IN_RWRD_ID::UUID;
    IN_CMPGN_ID_UUID := IN_CMPGN_ID::UUID;

    SQLCODE_PARM := '';
    RESP_CD := '';
    RESP_MSG := '';
    ERR_MSG := '';
    -- HV_RDM_TYPE_ID := 0;

    BEGIN
        SELECT RDM_TYPE_ID
        INTO HV_RDM_TYPE_ID
        FROM tgabm10.GABM_RDM_TYPE
        WHERE RDM_TYPE_CD = IN_RDM_TYPE_CD
        AND ACT_IN = 'Y'
        LIMIT 1;

        IF HV_RDM_TYPE_ID IS NULL THEN
            RESP_CD := 'E35031103';
            RESP_MSG := 'RDM TYPE CD NOT FOUND.';
            SQLCODE_PARM := '100';
            HV_RDM_TYPE_ID := 0;
        ELSE
            RESP_CD := 'E35031003';
            RESP_MSG := 'RDM TYPE CD FOUND.';
            SQLCODE_PARM := '0';
        END IF;
    EXCEPTION
        WHEN OTHERS THEN
            SQLCODE_PARM := SQLSTATE;
            RESP_CD := 'E35031903';
            RESP_MSG := 'THE SYSTEM CANNOT PROCESS YOUR REQUEST. PLEASE TRY AFTER SOME TIME.';
            ERR_MSG := SQLERRM;
            RETURN;
    END;

    BEGIN
        SELECT RDM_STA_ID
        INTO HV_RDM_STA_ID
        FROM tgabm10.GABM_RDM_STA
        WHERE RDM_STA_CD = IN_RDM_STA_CD
        AND ACT_IN = 'Y'
        LIMIT 1;

        IF HV_RDM_STA_ID IS NULL THEN
            RESP_CD := 'E35031101';
            RESP_MSG := 'RDM STA CD NOT FOUND.';
            SQLCODE_PARM := '100';
            HV_RDM_STA_ID := 0;
        ELSE
            RESP_CD := 'E35031001';
            RESP_MSG := 'RDM STA CD FOUND.';
            SQLCODE_PARM := '0';
        END IF;
    EXCEPTION
        WHEN OTHERS THEN
            SQLCODE_PARM := SQLSTATE;
            RESP_CD := 'E35031901';
            RESP_MSG := 'THE SYSTEM CANNOT PROCESS YOUR REQUEST. PLEASE TRY AFTER SOME TIME.';
            ERR_MSG := SQLERRM;
            RETURN;
    END;

    BEGIN
        INSERT INTO tgabm10.GABM_RDM_LOG (
            LOG_CREAT_TS,
            RDM_CD,
            RDM_TYPE_ID,
            RDM_STA_ID,
            RWRD_ID,
            CMPGN_ID,
            PTCP_ID,
            ACT_IN,
            CREAT_BY_PRCS_NM,
            CREAT_TS,
            LST_UPDT_BY_PRCS_NM,
            LST_UPDT_TS,
            RDM_CARD_TYPE_CD,
            API_REQ_ID
        ) VALUES (
            CURRENT_TIMESTAMP,
            IN_RDM_CD,
            HV_RDM_TYPE_ID,
            HV_RDM_STA_ID,
            IN_RWRD_ID_UUID,
            IN_CMPGN_ID_UUID,
            IN_PTCP_ID,
            IN_ACT_IN,
            IN_CREAT_BY_PRCS_NM,
            CURRENT_TIMESTAMP,
            IN_LST_UPDT_BY_PRCS_NM,
            CURRENT_TIMESTAMP,
            IN_RDM_CARD_TYPE_CD,
            IN_API_REQ_ID
        );

        GET DIAGNOSTICS SQLCODE = ROW_COUNT;

        IF SQLCODE > '0' THEN
            RESP_CD := 'E35031002';
            RESP_MSG := 'LOG INSERTED SUCCESSFULLY.';
            SQLCODE_PARM := '0';
        ELSE
            RESP_CD := 'E35031902';
            RESP_MSG := 'THE SYSTEM CANNOT PROCESS YOUR REQUEST. PLEASE TRY AFTER SOME TIME.';
            SQLCODE_PARM := '100';
        END IF;
    EXCEPTION
        WHEN OTHERS THEN
            SQLCODE_PARM := SQLSTATE;
            RESP_CD := 'E35031902';
            RESP_MSG := 'THE SYSTEM CANNOT PROCESS YOUR REQUEST. PLEASE TRY AFTER SOME TIME.';
            ERR_MSG := SQLERRM;
            RETURN;
    END;

    RETURN;
EXCEPTION
    WHEN OTHERS THEN
        SQLCODE_PARM := SQLSTATE;
        RESP_CD := 'E35031999';
        RESP_MSG := 'SQL EXCEPTION.CHECK SQLCODE TO FIX.';
        ERR_MSG := SQLERRM;
        RETURN;
END;
$$ LANGUAGE plpgsql;
GRANT EXECUTE ON FUNCTION tgabm10.e3rx5031 TO gabmusr;