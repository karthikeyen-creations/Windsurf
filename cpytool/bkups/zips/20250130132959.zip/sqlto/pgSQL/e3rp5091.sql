CREATE OR REPLACE FUNCTION tgabm10.e3rp5091(
		IN_APPL_CMPNT_RWRD_PARM_ID CHAR(36),
		IN_APPL_CMPNT_ID CHAR(36),
		IN_RWRD_ID CHAR(36),
		IN_PARM_NM CHAR(64),
		IN_PARM_VAL_TX VARCHAR(4096),
		IN_PARM_TYPE_TX CHAR(25),
		IN_PARM_GRP_NM CHAR(64),
		IN_ACT_IN CHAR(1),
		IN_CREAT_BY_PRCS_NM CHAR(255),
		IN_LST_UPDT_BY_PRCS_NM CHAR(255),
		OUT SQLCODE_PARM CHAR(10),
		OUT RESP_CD CHAR(14),
		OUT RESP_MSG CHAR(100),
		OUT ERR_MSG CHAR(100)
	) RETURNS RECORD AS $$
	DECLARE
		SQLCODE CHAR(10);
		REC_EXISTS INTEGER;
		IN_APPL_CMPNT_RWRD_PARM_ID_uuid UUID;
		IN_APPL_CMPNT_ID_uuid UUID;
		IN_RWRD_ID_uuid UUID;
	BEGIN
		IN_APPL_CMPNT_RWRD_PARM_ID_uuid := IN_APPL_CMPNT_RWRD_PARM_ID::UUID;
		IN_APPL_CMPNT_ID_uuid := IN_APPL_CMPNT_ID::UUID;
		IN_RWRD_ID_uuid := IN_RWRD_ID::UUID;

		SQLCODE_PARM := '';
		RESP_CD := '';
		RESP_MSG := '';
		ERR_MSG := '';

		BEGIN
			SELECT 1 INTO REC_EXISTS
			FROM tgabm10.gabm_rwrd_appl_cmpnt
			WHERE rwrd_id = IN_RWRD_ID_uuid
			  AND appl_cmpnt_id = IN_APPL_CMPNT_ID_uuid
			  AND act_in = 'Y'
			LIMIT 1;

			IF REC_EXISTS IS NULL THEN
                SQLCODE := '100';
				RESP_CD := 'E35091103';
				RESP_MSG := 'NO ACTIVE REWARD CMPNT ID FOUND.';
				SQLCODE_PARM := SQLCODE;
				RETURN;
			ELSE
                SQLCODE := '0';
				RESP_CD := 'E35091003';
				RESP_MSG := 'ACTIVE REWARD CMPNT ID FOUND.';
                SQLCODE_PARM := SQLCODE;
			END IF;
		EXCEPTION
			WHEN OTHERS THEN
                        SQLCODE := SQLSTATE;
				SQLCODE_PARM := SQLCODE;
				RESP_CD := 'E35091903';
				RESP_MSG := 'THE SYSTEM CANNOT PROCESS YOUR REQUEST. PLEASE TRY AFTER SOME TIME.';
				ERR_MSG := SQLERRM;
				RETURN;
		END;

		BEGIN
			IF EXISTS (
				SELECT 1
				FROM tgabm10.gabm_appl_cmpnt_rwrd_parm
				WHERE appl_cmpnt_rwrd_parm_id = IN_APPL_CMPNT_RWRD_PARM_ID_uuid
				LIMIT 1
			) THEN
                BEGIN
                    INSERT INTO tgabm10.gabm_appl_cmpnt_rwrd_parm_aud (
                        appl_cmpnt_rwrd_parm_id, aud_creat_ts, appl_cmpnt_id, rwrd_id, parm_nm, parm_val_tx, parm_type_tx, creat_ts, lst_updt_by_prcs_nm, lst_updt_ts
                    )
                    SELECT
                        appl_cmpnt_rwrd_parm_id, CURRENT_TIMESTAMP, appl_cmpnt_id, rwrd_id, parm_nm, parm_val_tx, parm_type_tx, creat_ts, lst_updt_by_prcs_nm, lst_updt_ts
                    FROM tgabm10.gabm_appl_cmpnt_rwrd_parm
                    WHERE appl_cmpnt_rwrd_parm_id = IN_APPL_CMPNT_RWRD_PARM_ID_uuid
                    LIMIT 1;

                    SQLCODE := '0';
                    RESP_CD := 'E35091002';
                    RESP_MSG := 'RWRD APPL COMP AUD UPDATED SUCCESSFULLY';
                    SQLCODE_PARM := SQLCODE;
                EXCEPTION
                WHEN OTHERS THEN
                        SQLCODE := SQLSTATE;
                    SQLCODE_PARM := SQLCODE;
                    RESP_CD := 'E35091902';
                    RESP_MSG := 'THE SYSTEM CANNOT PROCESS YOUR REQUEST. PLEASE TRY AFTER SOME TIME.';
                    ERR_MSG := SQLERRM;
                    RETURN;
                END;
                BEGIN
                    UPDATE tgabm10.gabm_appl_cmpnt_rwrd_parm
                    SET appl_cmpnt_id = IN_APPL_CMPNT_ID_uuid,
                        rwrd_id = IN_RWRD_ID_uuid,
                        parm_nm = IN_PARM_NM,
                        parm_val_tx = IN_PARM_VAL_TX,
                        parm_type_tx = IN_PARM_TYPE_TX,
                        parm_grp_nm = IN_PARM_GRP_NM,
                        act_in = IN_ACT_IN,
                        lst_updt_by_prcs_nm = IN_LST_UPDT_BY_PRCS_NM,
                        lst_updt_ts = CURRENT_TIMESTAMP
                    WHERE appl_cmpnt_rwrd_parm_id = IN_APPL_CMPNT_RWRD_PARM_ID_uuid;

                    SQLCODE := '0';
                    RESP_CD := 'E35091001';
                    RESP_MSG := 'RWRD APPL COMP DTL UPDATED SUCCESSFULLY';
                    SQLCODE_PARM := SQLCODE;
                    RETURN;
                EXCEPTION
                    WHEN OTHERS THEN
                        SQLCODE := SQLSTATE;
                        SQLCODE_PARM := SQLCODE;
                        RESP_CD := 'E35091901';
                        RESP_MSG := 'THE SYSTEM CANNOT PROCESS YOUR REQUEST. PLEASE TRY AFTER SOME TIME.';
                        ERR_MSG := SQLERRM;
                        RETURN;
                END;

        END CASE;   
			ELSE
                BEGIN
                    INSERT INTO tgabm10.gabm_appl_cmpnt_rwrd_parm (
                        appl_cmpnt_rwrd_parm_id, appl_cmpnt_id, rwrd_id, parm_nm, parm_val_tx, parm_type_tx, parm_grp_nm, act_in, creat_by_prcs_nm, creat_ts, lst_updt_by_prcs_nm, lst_updt_ts
                    )
                    VALUES (
                        IN_APPL_CMPNT_RWRD_PARM_ID_uuid, IN_APPL_CMPNT_ID_uuid, IN_RWRD_ID_uuid, IN_PARM_NM, IN_PARM_VAL_TX, IN_PARM_TYPE_TX, IN_PARM_GRP_NM, IN_ACT_IN, IN_CREAT_BY_PRCS_NM, CURRENT_TIMESTAMP, IN_LST_UPDT_BY_PRCS_NM, CURRENT_TIMESTAMP
                    );

                    SQLCODE := '0';
                    RESP_CD := 'E35091000';
                    RESP_MSG := 'RWRD APPL COMP DTL INSERTED SUCCESSFULLY';
                    SQLCODE_PARM := SQLCODE;
                    RETURN;
                EXCEPTION
                WHEN OTHERS THEN
                        SQLCODE := SQLSTATE;
                    SQLCODE_PARM := SQLCODE;
                    RESP_CD := 'E35091900';
                    RESP_MSG := 'THE SYSTEM CANNOT PROCESS YOUR REQUEST. PLEASE TRY AFTER SOME TIME.';  
                    ERR_MSG := SQLERRM;
                    RETURN;
                END;
			END IF;
		EXCEPTION
			WHEN OTHERS THEN
				SQLCODE_PARM := SQLCODE;
				RESP_CD := 'E35091902';
				RESP_MSG := 'THE SYSTEM CANNOT PROCESS YOUR REQUEST. PLEASE TRY AFTER SOME TIME.';
				ERR_MSG := SQLERRM;
				RETURN;
		END;
		RETURN;
    EXCEPTION
        WHEN OTHERS THEN    
            SQLCODE_PARM := SQLCODE;
            RESP_CD := 'E35091999';
            RESP_MSG := 'SQL EXCEPTION.CHECK SQLCODE TO FIX.';
            ERR_MSG := SQLERRM;
            RETURN;
	END;
	$$ LANGUAGE plpgsql;

	GRANT EXECUTE ON FUNCTION tgabm10.e3rp5091 TO
		XB1459A, 
		XB3375A, 
		XB1916A, 
		XB1914A, 
		XB2347A, 
		J081SE, 
		J0810OMS;