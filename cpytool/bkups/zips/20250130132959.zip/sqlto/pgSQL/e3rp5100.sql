CREATE OR REPLACE FUNCTION tgabm10.e3rp5100(
	IN_CMPGN_RWRD_SCHED_ID CHAR(36),
	IN_CMPGN_ID CHAR(25),
	IN_RWRD_ID CHAR(25),
	IN_SCHED_NM CHAR(64),
	IN_SCHED_STRT_TS TIMESTAMP,
	IN_SCHED_END_TS TIMESTAMP,
	IN_SCHED_TZ_TX CHAR(5),
	IN_ACT_IN CHAR(1),
	IN_CREAT_BY_PRCS_NM CHAR(255),
	IN_CREAT_TS TIMESTAMP,
	IN_LST_UPDT_BY_PRCS_NM CHAR(255),
	IN_LST_UPDT_TS TIMESTAMP,
	OUT SQLCODE_PARM CHAR(10),
	OUT RESP_CD CHAR(14),
	OUT RESP_MSG CHAR(100),
	OUT ERR_MSG CHAR(100)
) RETURNS RECORD AS $$
DECLARE
	SQLCODE CHAR(10);
	REC_EXISTS INTEGER;
	IN_CMPGN_RWRD_SCHED_ID_UUID UUID;
BEGIN
	IN_CMPGN_RWRD_SCHED_ID_UUID := IN_CMPGN_RWRD_SCHED_ID::UUID;

	SQLCODE_PARM := '';
	RESP_CD := '';
	RESP_MSG := '';
	ERR_MSG := '';

	BEGIN
		SELECT 1 INTO REC_EXISTS
		FROM tgabm10.gabm_cmpgn
		WHERE cmpgn_id = IN_CMPGN_ID
		AND cmpgn_end_dt >= CURRENT_DATE
		LIMIT 1;

		IF REC_EXISTS IS NULL THEN
			SQLCODE := '100';
		ELSE
			SQLCODE := '0';
		END IF;

		IF SQLCODE = '0' THEN
			RESP_CD := 'E35100000';
			RESP_MSG := 'CAMPAIGN ID FOUND.';
			SQLCODE_PARM := SQLCODE;
		ELSE
			RESP_CD := 'E35100100';
			RESP_MSG := 'NO ACTIVE CAMPAIGN FOUND.';
			SQLCODE_PARM := SQLCODE;
			RETURN;
		END IF;
	EXCEPTION
		WHEN OTHERS THEN
            SQLCODE := SQLSTATE;
            SQLCODE_PARM := SQLCODE;
            RESP_CD := 'E35100900';
            RESP_MSG := 'THE SYSTEM CANNOT PROCESS YOUR REQUEST. PLEASE TRY AFTER SOME TIME.';
            ERR_MSG := SQLERRM;
			RETURN;
	END;

	BEGIN
		SELECT 1 INTO REC_EXISTS
		FROM tgabm10.gabm_rwrd
		WHERE rwrd_id = IN_RWRD_ID
		AND act_in = 'Y'
		LIMIT 1;

		IF REC_EXISTS IS NULL THEN
			SQLCODE := '100';
		ELSE
			SQLCODE := '0';
		END IF;

		IF SQLCODE = '0' THEN
			RESP_CD := 'E35100001';
			RESP_MSG := 'REWARD ID FOUND.';
			SQLCODE_PARM := SQLCODE;
		ELSE
			RESP_CD := 'E35100101';
			RESP_MSG := 'NO ACTIVE REWARD FOUND.';
			SQLCODE_PARM := SQLCODE;
			RETURN;
		END IF;
	EXCEPTION
		WHEN OTHERS THEN
			SQLCODE := SQLSTATE;
			SQLCODE_PARM := SQLCODE;
			RESP_CD := 'E35100901';
			RESP_MSG := 'THE SYSTEM CANNOT PROCESS YOUR REQUEST. PLEASE TRY AFTER SOME TIME.';
			ERR_MSG := SQLERRM;
			RETURN;
	END;

	BEGIN
		IF EXISTS(
			SELECT 1
			FROM tgabm10.gabm_cmpgn_rwrd_sched
			WHERE cmpgn_rwrd_sched_id = IN_CMPGN_RWRD_SCHED_ID_UUID
			LIMIT 1
		    ) THEN
            BEGIN
                UPDATE tgabm10.gabm_cmpgn_rwrd_sched
                SET cmpgn_id = IN_CMPGN_ID,
                    rwrd_id = IN_RWRD_ID,
                    sched_nm = IN_SCHED_NM,
                    sched_strt_ts = IN_SCHED_STRT_TS,
                    sched_end_ts = IN_SCHED_END_TS,
                    sched_tz_tx = IN_SCHED_TZ_TX,
                    act_in = IN_ACT_IN,
                    lst_updt_by_prcs_nm = IN_LST_UPDT_BY_PRCS_NM,
                    lst_updt_ts = CURRENT_TIMESTAMP
                WHERE cmpgn_rwrd_sched_id = IN_CMPGN_RWRD_SCHED_ID_UUID;

                SQLCODE := '0';
				RESP_CD := 'E35100002';
				RESP_MSG := 'CMPGN RWRD SCHED UPDATED SUCCESSFULLY';
				SQLCODE_PARM := SQLCODE;
				RETURN;
			EXCEPTION WHEN OTHERS THEN
                SQLCODE := SQLSTATE;
				RESP_CD := 'E35100902';
				RESP_MSG := 'THE SYSTEM CANNOT PROCESS YOUR REQUEST. PLEASE TRY AFTER SOME TIME.';
				SQLCODE_PARM := SQLCODE;
				RETURN;
			END;
		ELSE
            BEGIN
                INSERT INTO tgabm10.gabm_cmpgn_rwrd_sched (
                    cmpgn_rwrd_sched_id,
                    cmpgn_id,
                    rwrd_id,
                    sched_nm,
                    sched_strt_ts,
                    sched_end_ts,
                    sched_tz_tx,
                    act_in,
                    creat_by_prcs_nm,
                    creat_ts,
                    lst_updt_by_prcs_nm,
                    lst_updt_ts
                ) VALUES (
                    IN_CMPGN_RWRD_SCHED_ID_UUID,
                    IN_CMPGN_ID,
                    IN_RWRD_ID,
                    IN_SCHED_NM,
                    IN_SCHED_STRT_TS,
                    IN_SCHED_END_TS,
                    IN_SCHED_TZ_TX,
                    IN_ACT_IN,
                    IN_CREAT_BY_PRCS_NM,
                    CURRENT_TIMESTAMP,
                    IN_LST_UPDT_BY_PRCS_NM,
                    CURRENT_TIMESTAMP
                );

                SQLCODE := '0';
				RESP_CD := 'E35100003';
				RESP_MSG := 'CMPGN RWRD SCHED INSERTED SUCCESSFULLY';
				SQLCODE_PARM := SQLCODE;
				RETURN;
			EXCEPTION WHEN OTHERS THEN
                SQLCODE := SQLSTATE;
				RESP_CD := 'E35100903';
				RESP_MSG := 'THE SYSTEM CANNOT PROCESS YOUR REQUEST. PLEASE TRY AFTER SOME TIME.';
				SQLCODE_PARM := SQLCODE;
				RETURN;
			END;
		END IF;
	END;
EXCEPTION
    WHEN OTHERS THEN
        SQLCODE := SQLSTATE;
        SQLCODE_PARM := SQLCODE;
        RESP_CD := 'E35100999';
        RESP_MSG := 'SQL EXCEPTION. CHECK SQLCODE TO FIX.';
        ERR_MSG := SQLERRM;
        RETURN;
END;
$$ LANGUAGE plpgsql;
GRANT EXECUTE ON FUNCTION tgabm10.e3rp5100 TO gabmusr;